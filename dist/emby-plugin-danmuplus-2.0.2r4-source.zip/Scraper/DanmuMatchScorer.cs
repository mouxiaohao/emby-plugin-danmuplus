using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using Emby.Plugin.Danmu.Core.Extensions;
using Emby.Plugin.Danmu.Model;
using Emby.Plugin.Danmu.Scraper.Entity;

namespace Emby.Plugin.Danmu.Scraper
{
    /// <summary>
    /// Scores search results without depending on a particular danmu provider.
    /// The episode count intentionally has a high weight because some providers
    /// use sequel titles that no longer contain the TMDB parent-series name.
    /// </summary>
    public static class DanmuMatchScorer
    {
        private static readonly Regex SeasonNumberRegex = new Regex(
            @"(?:第\s*[0-9一二三四五六七八九十百零〇两]+\s*季|season\s*\d+)",
            RegexOptions.Compiled | RegexOptions.IgnoreCase);

        private static readonly Regex SeparatorRegex = new Regex(
            @"[\s\p{P}\p{S}]+",
            RegexOptions.Compiled);

        public static List<string> BuildSearchKeywords(
            string seriesName,
            string seasonName,
            string keywordOverride)
        {
            var result = new List<string>();
            var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            var keyword = ExtractSeasonKeyword(seriesName, seasonName);

            if (!string.IsNullOrWhiteSpace(keywordOverride))
            {
                AddKeyword(result, seen, keywordOverride);
                return result;
            }

            // The parent title is deliberately the first search round.  Search callers
            // run each round against every enabled provider before moving on, so a
            // provider near the front of the configured list cannot win merely because
            // it happened to return a season-keyword result first.
            AddKeyword(result, seen, seriesName);
            if (!string.IsNullOrWhiteSpace(seriesName) && !string.IsNullOrWhiteSpace(keyword))
            {
                AddKeyword(result, seen, seriesName + " " + keyword);
            }

            AddKeyword(result, seen, seasonName);
            AddKeyword(result, seen, keyword);
            return result;
        }

        public static string ExtractSeasonKeyword(string seriesName, string seasonName)
        {
            var value = seasonName ?? string.Empty;
            if (!string.IsNullOrWhiteSpace(seriesName))
            {
                value = Regex.Replace(value, Regex.Escape(seriesName), string.Empty, RegexOptions.IgnoreCase);
            }

            value = SeasonNumberRegex.Replace(value, string.Empty);
            value = value.Trim(' ', ':', '：', '-', '–', '—', '_', '·', '.', '。');
            var normalized = Normalize(value);
            if (normalized.Length < 2 || normalized == "正片" || normalized == "本篇")
            {
                return string.Empty;
            }

            return value;
        }

        public static DanmuMatchCandidate Score(
            ScraperSearchInfo source,
            string site,
            string siteName,
            int sourceOrder,
            string seriesName,
            string seasonName,
            int? expectedYear,
            int expectedEpisodes,
            bool aliasDiscovered = false)
        {
            var title = Normalize(source.Name);
            var parent = Normalize(seriesName);
            var seasonKeyword = Normalize(ExtractSeasonKeyword(seriesName, seasonName));
            var combined = Normalize((seriesName ?? string.Empty) + (seasonKeyword ?? string.Empty));

            var parentScore = SimilarityAgainstTitle(parent, title);
            var keywordScore = SimilarityAgainstTitle(seasonKeyword, title);
            var combinedScore = SimilarityAgainstTitle(combined, title);
            double titleScore;

            if (!string.IsNullOrEmpty(seasonKeyword))
            {
                if (title.Contains(seasonKeyword))
                {
                    titleScore = 0.78 + (title.Contains(parent) && !string.IsNullOrEmpty(parent) ? 0.22 : 0.22 * parentScore);
                }
                else
                {
                    titleScore = Math.Max(combinedScore, keywordScore * 0.62 + parentScore * 0.38);
                }
            }
            else
            {
                titleScore = parentScore;
            }

            var yearScore = GetYearScore(expectedYear, source.Year);
            var episodeScore = GetEpisodeScore(expectedEpisodes, source.EpisodeSize);
            var score = aliasDiscovered
                ? titleScore * 0.35 + yearScore * 0.20 + episodeScore * 0.45
                : !string.IsNullOrEmpty(seasonKeyword)
                    ? titleScore * 0.45 + yearScore * 0.15 + episodeScore * 0.40
                    : titleScore * 0.55 + yearScore * 0.15 + episodeScore * 0.30;

            if (!aliasDiscovered && !string.IsNullOrEmpty(seasonKeyword) && keywordScore < 0.72)
            {
                score *= 0.72;
            }

            // Structural evidence may rescue an alternate title, but year/count
            // alone must never make an unrelated candidate automatic.
            if (aliasDiscovered && titleScore < 0.72)
            {
                score = Math.Min(score, 0.899);
            }

            if (!string.IsNullOrWhiteSpace(source.Category) && source.Category.Contains("电影"))
            {
                score *= 0.45;
            }

            score = Clamp(score);
            return new DanmuMatchCandidate
            {
                Id = source.Id ?? string.Empty,
                Site = site ?? string.Empty,
                SiteName = siteName ?? string.Empty,
                SourceOrder = sourceOrder,
                Name = source.Name ?? string.Empty,
                Category = source.Category ?? string.Empty,
                Year = source.Year,
                EpisodeSize = source.EpisodeSize,
                Score = Round(score),
                TitleScore = Round(titleScore),
                ParentTitleScore = Round(parentScore),
                KeywordScore = Round(keywordScore),
                YearScore = Round(yearScore),
                EpisodeScore = Round(episodeScore),
                Reason = BuildReason(parentScore, keywordScore, yearScore, episodeScore),
            };
        }

        public static DanmuMatchCandidate ScoreMovie(
            ScraperSearchInfo source,
            string site,
            string siteName,
            int sourceOrder,
            string movieName,
            int? expectedYear,
            bool aliasDiscovered = false)
        {
            var titleScore = SimilarityAgainstTitle(Normalize(movieName), Normalize(source.Name));
            var yearScore = GetYearScore(expectedYear, source.Year);
            var score = aliasDiscovered
                ? titleScore * 0.70 + yearScore * 0.30
                : titleScore * 0.82 + yearScore * 0.18;
            if (aliasDiscovered && titleScore < 0.72)
            {
                score = Math.Min(score, 0.899);
            }
            if (IsIdentifiableNonMovie(source.Category))
            {
                score = 0;
            }

            return new DanmuMatchCandidate
            {
                Id = source.Id ?? string.Empty,
                Site = site ?? string.Empty,
                SiteName = siteName ?? string.Empty,
                SourceOrder = sourceOrder,
                Name = source.Name ?? string.Empty,
                Category = source.Category ?? string.Empty,
                Year = source.Year,
                EpisodeSize = source.EpisodeSize,
                Score = Round(Clamp(score)),
                TitleScore = Round(titleScore),
                ParentTitleScore = Round(titleScore),
                YearScore = Round(yearScore),
                Reason = titleScore >= 0.95 && yearScore >= 0.95
                    ? "电影名和年份吻合"
                    : titleScore >= 0.95 ? "电影名吻合" : "需要人工确认",
            };
        }

        public static bool IsIdentifiableNonMovie(string category)
        {
            var normalized = (category ?? string.Empty).Trim().ToLowerInvariant();
            if (normalized.Length == 0)
            {
                return false;
            }

            if (normalized.Contains("电影") || normalized.Contains("movie") || normalized.Contains("film"))
            {
                return false;
            }

            return normalized.Contains("电视剧") || normalized.Contains("番剧") ||
                   normalized.Contains("动漫") || normalized.Contains("动画") ||
                   normalized.Contains("综艺") || normalized.Contains("season") ||
                   normalized == "tv" || normalized.Contains("series") || normalized.Contains("anime");
        }

        public static DanmuMatchCandidate SelectAutoCandidate(
            IList<DanmuMatchCandidate> candidates,
            bool allowProviderPriorityTie = true)
        {
            // r6 deliberately has one confidence rule.  Provider order decides the
            // winning site, then score decides only within that one site.  The
            // compatibility parameter is retained for callers compiled against r5;
            // partial search must no longer make an automatic decision at all.
            var confident = (candidates ?? new List<DanmuMatchCandidate>())
                .Where(x => x != null && x.Score >= 0.90)
                .ToList();
            if (confident.Count == 0)
            {
                return null;
            }

            var sourceOrder = confident.Min(x => x.SourceOrder);
            var preferredSite = confident
                .Where(x => x.SourceOrder == sourceOrder)
                .ToList();
            return SelectUniqueHighest(preferredSite);
        }

        public static bool CanAutoSelect(IList<DanmuMatchCandidate> candidates, bool allowProviderPriorityTie = true)
        {
            return SelectAutoCandidate(candidates, allowProviderPriorityTie) != null;
        }

        private static DanmuMatchCandidate SelectUniqueHighest(IList<DanmuMatchCandidate> candidates)
        {
            var highestScore = candidates.Max(x => x.Score);
            var winners = candidates.Where(x => x.Score == highestScore).ToList();
            return winners.Count == 1 ? winners[0] : null;
        }

        public static string Normalize(string value)
        {
            if (string.IsNullOrWhiteSpace(value))
            {
                return string.Empty;
            }

            // Providers and TMDB occasionally mix these homophones/variants.
            var normalized = value.Trim().ToLowerInvariant()
                .Replace('谭', '潭')
                .Replace('臺', '台')
                .Replace('裏', '里');
            return SeparatorRegex.Replace(normalized, string.Empty);
        }

        private static void AddKeyword(List<string> result, HashSet<string> seen, string value)
        {
            var keyword = (value ?? string.Empty).Trim();
            if (keyword.Length > 0 && seen.Add(keyword))
            {
                result.Add(keyword);
            }
        }

        private static double SimilarityAgainstTitle(string value, string title)
        {
            if (string.IsNullOrEmpty(value) || string.IsNullOrEmpty(title))
            {
                return 0;
            }

            if (title.Contains(value))
            {
                return 1;
            }

            var best = value.Distance(title);
            if (title.Length >= value.Length)
            {
                for (var index = 0; index <= title.Length - value.Length; index++)
                {
                    best = Math.Max(best, value.Distance(title.Substring(index, value.Length)));
                }
            }

            return Clamp(best);
        }

        private static double GetYearScore(int? expected, int? actual)
        {
            if (!expected.HasValue || expected.Value <= 0 || !actual.HasValue || actual.Value <= 0)
            {
                return 0.45;
            }

            var difference = Math.Abs(expected.Value - actual.Value);
            if (difference == 0)
            {
                return 1;
            }

            return difference == 1 ? 0.30 : 0;
        }

        private static double GetEpisodeScore(int expected, int actual)
        {
            if (expected <= 0 || actual <= 0)
            {
                return 0.45;
            }

            var difference = Math.Abs(expected - actual);
            if (difference == 0)
            {
                return 1;
            }

            if (difference == 1)
            {
                return 0.92;
            }

            return Clamp(1 - (double)difference / Math.Max(expected, actual));
        }

        private static string BuildReason(double parent, double keyword, double year, double episodes)
        {
            var parts = new List<string>();
            if (keyword >= 0.95) parts.Add("季名关键词吻合");
            if (parent >= 0.95) parts.Add("父剧名吻合");
            if (year >= 0.95) parts.Add("年份吻合");
            if (episodes >= 0.95) parts.Add("集数吻合");
            return parts.Count > 0 ? string.Join("、", parts) : "需要人工确认";
        }

        private static double Clamp(double value)
        {
            return Math.Max(0, Math.Min(1, value));
        }

        private static double Round(double value)
        {
            return Math.Round(value, 4, MidpointRounding.AwayFromZero);
        }
    }
}
