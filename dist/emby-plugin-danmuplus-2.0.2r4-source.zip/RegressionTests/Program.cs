using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Text;
using System.Reflection;
using System.Text.RegularExpressions;
using System.Xml;
using System.Xml.Serialization;
using Emby.Plugin.Danmu.Configuration;
using Emby.Plugin.Danmu.Core;
using Emby.Plugin.Danmu.Core.Extensions;
using Emby.Plugin.Danmu.Model;
using Emby.Plugin.Danmu.Scraper;
using Emby.Plugin.Danmu.Scraper.Bilibili;
using Emby.Plugin.Danmu.Scraper.Bilibili.Entity;
using Emby.Plugin.Danmu.Scraper.Dandan;
using Emby.Plugin.Danmu.Scraper.Entity;
using Emby.Plugin.Danmu.Scraper.Iqiyi;
using MediaBrowser.Controller.Entities;
using MediaBrowser.Controller.Entities.Movies;
using MediaBrowser.Controller.Entities.TV;
using MediaBrowser.Model.Logging;
using System.Threading;
using System.Threading.Tasks;
using BilibiliMedia = Emby.Plugin.Danmu.Scraper.Bilibili.Entity.Media;

namespace Emby.Plugin.Danmu.RegressionTests
{
    internal static class Program
    {
        private static int Main()
        {
            MapsAnimeSeason();
            MapsLiveActionSeasonAndCleansTitle();
            UsesIdentifierFallbackOrder();
            OmitsMalformedRecords();
            OrdersAndSelectsCrossProviderTies();
            PreservesSameSiteHighestScoreTieAmbiguity();
            SelectsCloseHighConfidenceCandidatesBySitePriority();
            ScoresMoviesAndFiltersTelevisionCandidates();
            ScoresAliasCandidatesWithStructuralEvidence();
            DiscoversMovieAliasesAndPreservesStandardProvenance();
            IsolatesMovieProviderFailures();
            ResolvesProviderIdsBySiteThenHierarchy();
            EnforcesItemLocalProviderScopes();
            DiscoversCandidatesWithBoundedTitleClauses();
            NormalizesDandanStandaloneSeasonOrdinals();
            EnforcesBilibiliPgcIdentifierPolicy();
            ExposesBilibiliAndMgtvExternalIds();
            PreservesSeasonSuccessPersistenceContract();
            PreservesSeriesPreviewProviderIdContract();
            ProjectsProviderIdMetadataWithoutSearchOrScoring();
            PreservesProviderDetailAdapterMetadataContracts();
            RequiresVerifiedDirectEpisodeDetailsAndUsesResolvedUgcCounts();
            ResolvesMovieProviderLookupIdentifiers();
            PreservesSavedManualBindingsUntilForcedSearch();
            AppliesDuplicateAndForceRefreshPolicy();
            PreservesSingleEpisodeIsolationAndLegacyTaskShape();
            PreservesProviderWriteGenerationOrdering();
            ReplacesOnlyRegisteredOrdinaryProviderIds();
            MapsEpisodeSourceNumbersSafely();
            DeserializesAndNormalizesBilibiliEpisodes();
            DeserializesBilibiliExactVideoDetails();
            DeserializesBilibiliExactSeasonDetails();
            ClassifiesOnlyExplicitNonMainTitles();
            ResolvesDandanCredentialsByCompletePair();
            RejectsIncompleteDandanCredentialsWithoutLeakingValues();
            PreservesLegacyDandanApiDefaults();
            MigratesOfficialProxyCorsConfigurationWithoutPersistingItsAddress();
            NormalizesAndValidatesDandanProxyPrefixes();
            RoutesExistingDandanEndpointsWithoutLocalProxyAuthentication();
            PreservesDandanTitleBasedMatchingEndpoints();
            EmbedsDandanCredentialSettings();
            VerifiesVersionedConfigurationPageResources();
            VerifiesSingleTargetSmartMatchReliabilityContracts();
            PreservesValidUnicodeWhileRemovingInvalidXmlScalars();
            RemovesInvalidXmlCharacterReferences();
            PreservesCharacterReferenceTextInsideCdata();
            RecoversIqiyiXmlContainingInvalidCharacters();
            ParsesIqiyiQipsMovieTvId();
            RecoversBilibiliXmlContainingInvalidCharacters();
            SanitizesFinalXmlForEveryProviderAndAcceptsSmallValidOutput();
            Console.WriteLine("Danmu plugin regression checks passed.");
            return 0;
        }

        private static void PreservesProviderWriteGenerationOrdering()
        {
            var tracker = new ProviderWriteGenerationTracker();
            const string firstSite = "item\u001fBilibiliID";
            const string secondSite = "item\u001fDandanID";

            tracker.MarkCommitted(firstSite, 2);
            Assert(tracker.IsStale(firstSite, 1, out var committed) && committed == 2,
                "a late older write must not replace a newer successful provider binding");
            Assert(!tracker.IsStale(firstSite, 2, out _),
                "the current generation must remain writable");

            tracker.MarkStarted(firstSite, 4);
            Assert(tracker.IsStale(firstSite, 3, out var latestStarted) && latestStarted == 4,
                "a newer started task must supersede an older task before either one commits");
            Assert(!tracker.IsStale(secondSite, 1, out _),
                "a provider generation must not suppress another provider's binding");

            tracker.MarkCommitted(firstSite, 1);
            Assert(tracker.IsStale(firstSite, 1, out committed) && committed == 4,
                "an older completion must not lower committed or latest-started protection");

            var successful = new DanmuEpisodeDownloadOutcome
            {
                Status = "success",
                FilePersisted = true,
                ProviderId = "BilibiliID",
                ProviderValue = "new-id",
            };
            Assert(DanmuDownloadPersistencePolicy.ShouldPersist(successful),
                "a completed successful download should persist only its selected provider");
            successful.Status = "partial";
            Assert(DanmuDownloadPersistencePolicy.ShouldPersist(successful),
                "a partial result with a persisted valid XML should update its successful target");
            successful.Status = "failed";
            Assert(!DanmuDownloadPersistencePolicy.ShouldPersist(successful),
                "a failed download must preserve existing metadata");
            successful.Status = "skipped";
            Assert(!DanmuDownloadPersistencePolicy.ShouldPersist(successful),
                "a skipped download must preserve existing metadata");
            successful.Status = "success";
            successful.FilePersisted = false;
            Assert(!DanmuDownloadPersistencePolicy.ShouldPersist(successful),
                "a successful status without an actual file must not persist metadata");
        }

        private static void MapsAnimeSeason()
        {
            var source = new BilibiliMedia
            {
                SeasonId = 46089,
                MediaId = 21087073,
                Title = "<em class=\"keyword\">葬送的芙莉莲</em>",
                SeasonTypeName = "番剧",
                PubDate = "2023-09-29 18:00:00",
                EpisodeSize = 28
            };

            Assert(BilibiliSearchResultMapper.TryMap(source, out var result, out _), "anime should map");
            Assert(result.Id == "46089", "anime should use season_id");
            Assert(result.Name == "葬送的芙莉莲", "highlight markup should be removed");
            Assert(result.Year == 2023 && result.EpisodeSize == 28 && result.Category == "番剧", "anime metadata should be preserved");
        }

        private static void MapsLiveActionSeasonAndCleansTitle()
        {
            var source = new BilibiliMedia
            {
                SeasonId = 34793,
                Title = "<em class=\"keyword\">半泽直树</em>",
                SeasonTypeName = "电视剧",
                PubTime = 1373126400,
                EpisodeSize = 10
            };

            Assert(BilibiliSearchResultMapper.TryMap(source, out var result, out _), "live-action season should map");
            Assert(result.Id == "34793" && result.Name == "半泽直树", "live-action identity should be preserved");
            Assert(result.Year == 2013 && result.EpisodeSize == 10 && result.Category == "电视剧", "live-action metadata should be preserved");
        }

        private static void UsesIdentifierFallbackOrder()
        {
            var source = new BilibiliMedia { SeasonId = 7, PgcSeasonId = 8, MediaId = 9, Title = "A" };
            Assert(BilibiliSearchResultMapper.ResolveId(source) == 7, "season_id should win");
            source.SeasonId = 0;
            Assert(BilibiliSearchResultMapper.ResolveId(source) == 8, "pgc_season_id should be the second choice");
            source.PgcSeasonId = 0;
            Assert(BilibiliSearchResultMapper.ResolveId(source) == 9, "media_id should be the final positive fallback");
        }

        private static void OmitsMalformedRecords()
        {
            Assert(!BilibiliSearchResultMapper.TryMap(new BilibiliMedia { Title = "No ID" }, out _, out _), "record without identifier should be omitted");
            Assert(!BilibiliSearchResultMapper.TryMap(new BilibiliMedia { SeasonId = 1, Title = " " }, out _, out _), "record without title should be omitted");
        }

        private static void OrdersAndSelectsCrossProviderTies()
        {
            var candidates = DanmuMatchSearchEngine.OrderCandidates(new List<DanmuMatchCandidate>
            {
                Candidate("later", "LaterSite", 2, 0.90),
                Candidate("priority", "PrioritySite", 0, 0.90),
                Candidate("middle", "MiddleSite", 1, 0.82)
            });

            Assert(candidates[0].Id == "priority", "r6 should surface the selected configured provider first");
            Assert(DanmuMatchScorer.CanAutoSelect(candidates), "a unique candidate on the highest-priority tied provider should auto-bind");
            Assert(DanmuMatchScorer.CanAutoSelect(candidates, false), "r6 selection must not depend on legacy intermediate-search behavior");

            var unequal = DanmuMatchSearchEngine.OrderCandidates(new List<DanmuMatchCandidate>
            {
                Candidate("higher-score", "LaterSite", 5, 0.91),
                Candidate("higher-priority", "PrioritySite", 0, 0.90)
            });
            Assert(unequal[0].Id == "higher-priority", "an earlier 0.90 site must outrank a later 0.91 site");

            var crowded = Enumerable.Range(0, 61)
                .Select(index => Candidate("later-" + index, "LaterSite", 5, 1.0))
                .Append(Candidate("priority-after-cutoff", "PrioritySite", 0, 0.90))
                .ToList();
            var crowdedOrdered = DanmuMatchSearchEngine.OrderCandidates(crowded);
            Assert(crowdedOrdered.Count == 60 && crowdedOrdered[0].Id == "priority-after-cutoff",
                "the confident site-priority decision must run before the 60-candidate display limit");
        }

        private static void PreservesSameSiteHighestScoreTieAmbiguity()
        {
            var candidates = DanmuMatchSearchEngine.OrderCandidates(new List<DanmuMatchCandidate>
            {
                Candidate("a", "PrioritySite", 0, 0.99),
                Candidate("b", "PrioritySite", 0, 0.99),
                Candidate("c", "LaterSite", 1, 0.99)
            });
            Assert(!DanmuMatchScorer.CanAutoSelect(candidates),
                "multiple same-score winners within the highest-priority site must remain ambiguous");

            var oneSite = DanmuMatchSearchEngine.OrderCandidates(new List<DanmuMatchCandidate>
            {
                Candidate("same-site-high", "PrioritySite", 0, 0.90),
                Candidate("same-site-low", "PrioritySite", 0, 0.89),
                Candidate("non-competing-site", "LaterSite", 1, 0.64)
            });
            Assert(DanmuMatchScorer.SelectAutoCandidate(oneSite)?.Id == "same-site-high" &&
                   DanmuMatchScorer.SelectAutoCandidate(oneSite, false)?.Id == "same-site-high",
                "one-site competitors should select their unique highest score even during intermediate search");
        }

        private static void SelectsCloseHighConfidenceCandidatesBySitePriority()
        {
            var preferredRunnerUp = DanmuMatchSearchEngine.OrderCandidates(new List<DanmuMatchCandidate>
            {
                Candidate("full", "LaterSite", 2, 1.0),
                Candidate("preferred", "PrioritySite", 0, 0.98)
            });
            Assert(preferredRunnerUp[0].Id == "preferred" &&
                   DanmuMatchScorer.SelectAutoCandidate(preferredRunnerUp)?.Id == "preferred",
                "r6 should select and display the earlier confident site");

            var outsideGap = DanmuMatchSearchEngine.OrderCandidates(new List<DanmuMatchCandidate>
            {
                Candidate("full", "FullSite", 1, 1.0),
                Candidate("outside", "PrioritySite", 0, 0.969)
            });
            Assert(DanmuMatchScorer.SelectAutoCandidate(outsideGap)?.Id == "outside",
                "r6 ignores cross-site score gaps inside the confident pool");

            var belowPoolFloor = DanmuMatchSearchEngine.OrderCandidates(new List<DanmuMatchCandidate>
            {
                Candidate("higher", "LaterSite", 1, 0.949),
                Candidate("lower", "PrioritySite", 0, 0.94)
            });
            Assert(DanmuMatchScorer.SelectAutoCandidate(belowPoolFloor)?.Id == "lower",
                "the r6 0.90 boundary includes an earlier 0.94 candidate");

            var floorBoundary = DanmuMatchSearchEngine.OrderCandidates(new List<DanmuMatchCandidate>
            {
                Candidate("floor", "LaterSite", 1, 0.95),
                Candidate("below-floor", "PrioritySite", 0, 0.92)
            });
            Assert(DanmuMatchScorer.SelectAutoCandidate(floorBoundary)?.Id == "below-floor",
                "the 0.90 boundary includes an earlier 0.92 candidate");

            var samePreferredSite = DanmuMatchSearchEngine.OrderCandidates(new List<DanmuMatchCandidate>
            {
                Candidate("preferred-high", "PrioritySite", 0, 0.99),
                Candidate("preferred-low", "PrioritySite", 0, 0.98),
                Candidate("later", "LaterSite", 1, 0.97)
            });
            Assert(DanmuMatchScorer.SelectAutoCandidate(samePreferredSite)?.Id == "preferred-high",
                "the highest-scoring close candidate within the earliest site should win when unique");

            var preferredThirdScore = DanmuMatchSearchEngine.OrderCandidates(new List<DanmuMatchCandidate>
            {
                Candidate("full", "LateSite", 3, 1.0),
                Candidate("second", "MiddleSite", 2, 0.99),
                Candidate("preferred", "PrioritySite", 0, 0.98)
            });
            Assert(preferredThirdScore.Select(x => x.Id).SequenceEqual(new[] { "preferred", "full", "second" }) &&
                   DanmuMatchScorer.SelectAutoCandidate(preferredThirdScore)?.Id == "preferred",
                "the earliest confident site wins over all later scores");

            Assert(DanmuMatchScorer.SelectAutoCandidate(preferredRunnerUp, false)?.Id == "preferred" &&
                   DanmuMatchScorer.SelectAutoCandidate(outsideGap, false)?.Id == "outside",
                "legacy selector flags must not reintroduce r5 behavior");

            var exactTie = DanmuMatchSearchEngine.OrderCandidates(new List<DanmuMatchCandidate>
            {
                Candidate("late-tie", "LaterSite", 2, 0.98),
                Candidate("priority-tie", "PrioritySite", 0, 0.98)
            });
            Assert(DanmuMatchScorer.SelectAutoCandidate(exactTie)?.Id == "priority-tie" &&
                   DanmuMatchScorer.SelectAutoCandidate(exactTie, false)?.Id == "priority-tie",
                "cross-site ties resolve to the earliest configured site");

            Assert(DanmuMatchScorer.SelectAutoCandidate(new List<DanmuMatchCandidate>
                {
                    Candidate("below-floor", "Site", 0, 0.77)
                }) == null,
                "scores below the r6 0.90 boundary must remain unselected");
            Assert(DanmuMatchScorer.SelectAutoCandidate(new List<DanmuMatchCandidate>
                {
                    Candidate("strong", "SiteA", 0, 0.78),
                    Candidate("weak-runner-up", "SiteB", 1, 0.64)
                }) == null,
                "scores below the r6 0.90 boundary must remain unselected");
        }

        private static void ScoresMoviesAndFiltersTelevisionCandidates()
        {
            var exact = DanmuMatchScorer.ScoreMovie(
                new ScraperSearchInfo { Id = "movie", Name = "流浪地球", Category = "电影", Year = 2019 },
                "MovieSite", "Movie Site", 1, "流浪地球", 2019);
            var weaker = DanmuMatchScorer.ScoreMovie(
                new ScraperSearchInfo { Id = "weaker", Name = "流浪地球2", Category = "电影", Year = 2023 },
                "MovieSite", "Movie Site", 1, "流浪地球", 2019);
            var television = DanmuMatchScorer.ScoreMovie(
                new ScraperSearchInfo { Id = "tv", Name = "流浪地球", Category = "电视剧", Year = 2019 },
                "MovieSite", "Movie Site", 1, "流浪地球", 2019);
            var ordered = DanmuMatchSearchEngine.OrderCandidates(new[] { weaker, exact });

            Assert(ordered[0].Id == "movie" && ordered[0].Score >= ordered[1].Score,
                "movie candidates should be ordered by deterministic descending score");
            Assert(DanmuMatchScorer.CanAutoSelect(ordered), "a distinct exact movie match should auto-select");
            Assert(television.Score == 0 && DanmuMatchScorer.IsIdentifiableNonMovie("番剧"),
                "identifiable television candidates must be rejected for movies");
        }

        private static void ScoresAliasCandidatesWithStructuralEvidence()
        {
            var source = new ScraperSearchInfo
            {
                Id = "alias-season",
                Name = "abcdefzzzz",
                Year = 2024,
                EpisodeSize = 12,
            };
            var standard = DanmuMatchScorer.Score(
                source, "AliasID", "Alias", 0, "abcdefghij", "abcdefghij", 2024, 12);
            var alias = DanmuMatchScorer.Score(
                source, "AliasID", "Alias", 0, "abcdefghij", "abcdefghij", 2024, 12, true);
            var expectedAlias = Math.Round(
                alias.TitleScore * 0.35 + alias.YearScore * 0.20 + alias.EpisodeScore * 0.45,
                4,
                MidpointRounding.AwayFromZero);

            Assert(alias.TitleScore >= 0.72 && alias.Score == expectedAlias && alias.Score >= 0.90,
                "an alias-only season with related title and exact year/count must use 35/20/45 and reach confidence");
            Assert(Math.Abs(standard.Score - Math.Round(
                       standard.TitleScore * 0.55 + standard.YearScore * 0.15 + standard.EpisodeScore * 0.30,
                       4,
                       MidpointRounding.AwayFromZero)) < 0.0001,
                "standard discovery must retain the existing no-keyword season weights");

            var unrelated = DanmuMatchScorer.Score(
                new ScraperSearchInfo
                {
                    Id = "unrelated",
                    Name = "zzzzzzzzzz",
                    Year = 2024,
                    EpisodeSize = 12,
                },
                "AliasID", "Alias", 0, "abcdefghij", "abcdefghij", 2024, 12, true);
            Assert(unrelated.TitleScore < 0.72 && unrelated.Score < 0.90,
                "exact year/count must not rescue an alias below the 0.72 title floor");

            var movieAlias = DanmuMatchScorer.ScoreMovie(
                new ScraperSearchInfo
                {
                    Id = "alias-movie",
                    Name = "abcdefzzzz",
                    Category = "movie",
                    Year = 2024,
                },
                "AliasID", "Alias", 0, "abcdefghij", 2024, true);
            Assert(movieAlias.Score == Math.Round(
                       movieAlias.TitleScore * 0.70 + movieAlias.YearScore * 0.30,
                       4,
                       MidpointRounding.AwayFromZero),
                "alias-only movies must use 70/30 title/year scoring");
        }

        private static void DiscoversMovieAliasesAndPreservesStandardProvenance()
        {
            const string movieName = "Alpha Adventure：Hidden Alias";
            var provider = new FakeScraper(
                "MovieAliasID",
                null,
                false,
                null,
                null,
                null,
                new Dictionary<string, List<ScraperSearchInfo>>(StringComparer.OrdinalIgnoreCase)
                {
                    [movieName] = new List<ScraperSearchInfo>(),
                    ["Hidden Alias"] = new List<ScraperSearchInfo>
                    {
                        new ScraperSearchInfo
                        {
                            Id = "movie-alias",
                            Name = movieName,
                            Category = "movie",
                            Year = 2024,
                        },
                    },
                });
            var result = DanmuMatchSearchEngine.SearchMovieAsync(
                    new[] { provider },
                    new Movie { Name = movieName, ProductionYear = 2024 },
                    null,
                    null)
                .GetAwaiter().GetResult();

            Assert(provider.SearchNames.Contains("Hidden Alias") &&
                   result.Candidates.Any(x => x.Id == "movie-alias" && x.Score >= 0.90),
                "Movie search must apply bounded local clauses through the Movie-specific provider path");

            var duplicateProvider = new FakeScraper(
                "MovieDuplicateID",
                null,
                false,
                null,
                null,
                null,
                new Dictionary<string, List<ScraperSearchInfo>>(StringComparer.OrdinalIgnoreCase)
                {
                    [movieName] = new List<ScraperSearchInfo>
                    {
                        new ScraperSearchInfo
                        {
                            Id = "same",
                            Name = "Alpha Adventure",
                            Category = "movie",
                            Year = 2000,
                        },
                    },
                    ["Hidden Alias"] = new List<ScraperSearchInfo>
                    {
                        new ScraperSearchInfo
                        {
                            Id = "same",
                            Name = movieName,
                            Category = "movie",
                            Year = 2024,
                        },
                    },
                });
            var duplicate = DanmuMatchSearchEngine.SearchMovieAsync(
                    new[] { duplicateProvider },
                    new Movie { Name = movieName, ProductionYear = 2024 },
                    null,
                    null)
                .GetAwaiter().GetResult();
            Assert(duplicate.Candidates.Count(x => x.Id == "same") == 1 &&
                   duplicate.Candidates.Single(x => x.Id == "same").Year == 2000,
                "a standard-first candidate must retain standard provenance and metadata when an alias round repeats it");
        }

        private static void ReplacesOnlyRegisteredOrdinaryProviderIds()
        {
            var current = new MediaBrowser.Model.Entities.ProviderIdDictionary
            {
                ["BilibiliID"] = "old-bili",
                ["DandanID"] = "old-dandan",
                ["IqiyiID"] = "disabled-iqiyi",
                ["BilibiliIDManual"] = "manual-bili",
                ["DandanIDManual"] = "manual-dandan",
                ["Tmdb"] = "tmdb-1",
                ["Tvdb"] = "tvdb-1",
                ["Imdb"] = "imdb-1",
                ["CustomID"] = "custom-1",
            };
            var updated = DanmuProviderIdWritePolicy.BuildSuccessfulWrite(
                current,
                new[] { "BilibiliID", "DandanID", "IqiyiID", "MgtvID" },
                "DandanID",
                "new-dandan",
                true);

            Assert(updated["DandanID"] == "new-dandan" &&
                   !updated.ContainsKey("BilibiliID") &&
                   !updated.ContainsKey("IqiyiID") &&
                   updated["BilibiliIDManual"] == "manual-bili" &&
                   updated["DandanIDManual"] == "manual-dandan" &&
                   updated["Tmdb"] == "tmdb-1" && updated["Tvdb"] == "tvdb-1" &&
                   updated["Imdb"] == "imdb-1" && updated["CustomID"] == "custom-1",
                "successful Season/Episode writes must remove all registered ordinary IDs, including disabled sites, and preserve Manual/non-plugin keys");
            Assert(current["BilibiliID"] == "old-bili" && current["DandanID"] == "old-dandan",
                "the pure provider-ID policy must not mutate its input dictionary before repository persistence");

            var movieStyle = DanmuProviderIdWritePolicy.BuildSuccessfulWrite(
                current,
                new[] { "BilibiliID", "DandanID", "IqiyiID" },
                "DandanID",
                "movie-upsert",
                false);
            Assert(movieStyle["BilibiliID"] == "old-bili" && movieStyle["IqiyiID"] == "disabled-iqiyi",
                "upsert-only paths such as Movie and pre-download bindings must not apply Season/Episode cleanup");
        }

        private static void IsolatesMovieProviderFailures()
        {
            var search = DanmuMatchSearchEngine.SearchMovieAsync(
                    new AbstractScraper[]
                    {
                        new FakeScraper("WorkingID", new List<ScraperSearchInfo>
                        {
                            new ScraperSearchInfo { Id = "1", Name = "测试电影", Category = "电影", Year = 2024 },
                        }),
                        new FakeScraper("DandanID", null, true),
                    },
                    new Movie { Name = "测试电影", ProductionYear = 2024 },
                    string.Empty,
                    null)
                .GetAwaiter().GetResult();

            Assert(search.Candidates.Count == 1, "successful movie providers should still contribute candidates");
            Assert(search.SearchErrors.Count == 1 && search.SearchErrors[0].Contains("DandanID"),
                "a failed Dandan proxy provider should be isolated in diagnostics");
        }

        private static void ResolvesProviderIdsBySiteThenHierarchy()
        {
            var early = new FakeScraper("EarlyID", null, false, new Dictionary<string, ScraperMedia>
            {
                ["season-id"] = new ScraperMedia { Id = "season-id" },
                ["current-id"] = new ScraperMedia { Id = "current-id" },
            });
            var late = new FakeScraper("LateID", null, false, new Dictionary<string, ScraperMedia>
            {
                ["episode-id"] = new ScraperMedia { Id = "episode-id" },
            });
            var current = new Movie { Name = "current" };
            var season = new Movie { Name = "season" };
            current.ProviderIds["LateID"] = "episode-id";
            season.ProviderIds["EarlyID"] = "season-id";

            var crossSite = DanmuProviderIdResolver.ResolveAsync(
                    new AbstractScraper[] { early, late },
                    new BaseItem[] { current, season },
                    null)
                .GetAwaiter().GetResult();
            Assert(crossSite.Candidate?.Id == "season-id" && crossSite.MatchOrigin == "provider-id",
                "the earlier enabled site must beat a later current-item ProviderId");

            current.ProviderIds["EarlyID"] = "current-id";
            var sameSite = DanmuProviderIdResolver.ResolveAsync(
                    new AbstractScraper[] { early, late },
                    new BaseItem[] { current, season },
                    null)
                .GetAwaiter().GetResult();
            Assert(sameSite.Candidate?.Id == "current-id",
                "within an enabled site, current-item ProviderId must beat the parent value");

            var episodeScraper = new FakeScraper(
                "EpisodeID",
                null,
                false,
                null,
                new Dictionary<string, ScraperEpisode>
                {
                    ["episode-provider-id"] = new ScraperEpisode
                    {
                        Id = "episode-provider-id",
                        CommentId = "episode-comment-id",
                        EpisodeNumber = 3,
                    },
                    ["episode-without-number"] = new ScraperEpisode
                    {
                        Id = "episode-without-number",
                        CommentId = "episode-comment-without-number",
                    },
                    ["episode-without-comment"] = new ScraperEpisode
                    {
                        Id = "episode-without-comment",
                    },
                });
            var episodeItem = new Episode { Name = "episode", IndexNumber = 3 };
            episodeItem.ProviderIds["EpisodeID"] = "episode-provider-id";
            var episodeDecision = DanmuProviderIdResolver.ResolveAsync(
                    new AbstractScraper[] { episodeScraper },
                    new BaseItem[] { episodeItem },
                    null)
                .GetAwaiter().GetResult();
            Assert(episodeDecision.Candidate?.Id == "episode-provider-id" &&
                   episodeDecision.Media?.Episodes.Single().CommentId == "episode-comment-id",
                "Episode ProviderIds must resolve through GetMediaEpisode rather than the season-media API");
            var directMedia = DanmuProviderIdResolver.ResolveDirectEpisodeMediaAsync(
                    episodeScraper, episodeItem, "episode-provider-id", 3)
                .GetAwaiter().GetResult();
            Assert(directMedia?.Episodes.Single().CommentId == "episode-comment-id" &&
                   directMedia.Episodes.Single().EpisodeNumber == 3 &&
                   episodeScraper.MediaCalls == 0 && episodeScraper.MediaEpisodeCalls >= 2,
                "direct Episode ProviderIds must retain the exact GetMediaEpisode result for download without calling GetMedia");

            var noNumberEpisode = new Episode { Name = "episode without local number" };
            noNumberEpisode.ProviderIds["EpisodeID"] = "episode-without-number";
            var noNumberDecision = DanmuProviderIdResolver.ResolveAsync(
                    new AbstractScraper[] { episodeScraper },
                    new BaseItem[] { noNumberEpisode },
                    null)
                .GetAwaiter().GetResult();
            Assert(noNumberDecision.Candidate?.Id == "episode-without-number" &&
                   noNumberDecision.Media?.Episodes.Single().EpisodeNumber == 1 &&
                   noNumberDecision.ResolvedScopeType == "Episode",
                "an exact Episode ProviderId must remain usable without a local IndexNumber");

            var noCommentEpisode = new Episode { Name = "episode without comment", IndexNumber = 1 };
            noCommentEpisode.ProviderIds["EpisodeID"] = "episode-without-comment";
            var noCommentDecision = DanmuProviderIdResolver.ResolveAsync(
                    new AbstractScraper[] { episodeScraper },
                    new BaseItem[] { noCommentEpisode },
                    null)
                .GetAwaiter().GetResult();
            Assert(noCommentDecision.Candidate == null &&
                   noCommentDecision.Diagnostics.Any(x => x.StartsWith("provider-id-unresolved")),
                "an Episode ProviderId without a downloadable comment id must fall through as stale");

            var parentSeries = new Series { Name = "parent series" };
            parentSeries.ProviderIds["EarlyID"] = "season-id";
            var callsBeforeSeriesScope = early.MediaCalls;
            var seriesScopeDecision = DanmuProviderIdResolver.ResolveAsync(
                    new AbstractScraper[] { early },
                    new BaseItem[] { new Season { Name = "child season" }, parentSeries },
                    null)
                .GetAwaiter().GetResult();
            Assert(seriesScopeDecision.Candidate == null && early.MediaCalls == callsBeforeSeriesScope,
                "Series ProviderIds must remain untouched and unread even when accidentally supplied to the resolver");

            current.ProviderIds["EarlyID"] = "stale-current";
            season.ProviderIds["EarlyID"] = "stale-season";
            var stale = DanmuProviderIdResolver.ResolveAsync(
                    new AbstractScraper[] { early },
                    new BaseItem[] { current, season },
                    null)
                .GetAwaiter().GetResult();
            var bindings = new Dictionary<string, string> { ["EarlyIDManual"] = "manual-id" };
            Assert(stale.Candidate == null && stale.Diagnostics.Any(x => x.StartsWith("provider-id-unresolved")) &&
                   DanmuMatchBindingHelper.TryGetSavedManualBinding(
                       false, new[] { early }, bindings, out _, out var manualId) && manualId == "manual-id" &&
                   !DanmuMatchBindingHelper.TryGetSavedManualBinding(
                       true, new[] { early }, bindings, out _, out _),
                "stale identifiers must continue to binding while rematch bypasses it without deleting it");
        }

        private static void ResolvesMovieProviderLookupIdentifiers()
        {
            var media = new ScraperMedia
            {
                Id = "season-or-album-id",
                CommentId = "470296",
                Episodes = new List<ScraperEpisode>
                {
                    new ScraperEpisode { Id = "470296", CommentId = "fallback-episode-id" },
                },
            };
            Assert(DanmuMovieMatchHelper.ResolveEpisodeLookupId("BilibiliID", media) == "470296",
                "Bilibili movies should resolve through their ep id");
            Assert(DanmuMovieMatchHelper.ResolveEpisodeLookupId("IqiyiID", media) == "season-or-album-id",
                "non-Bilibili movies should resolve through their provider media id");
            media.CommentId = string.Empty;
            Assert(DanmuMovieMatchHelper.ResolveEpisodeLookupId("BilibiliID", media) == "470296",
                "Bilibili movie lookup should fall back only to a durable numeric episode ep_id");
        }

        private static void EnforcesItemLocalProviderScopes()
        {
            var movie = new Movie { Name = "movie" };
            var season = new Season { Name = "season" };
            var episode = new Episode { Name = "episode" };
            var series = new Series { Name = "series" };

            Assert(DanmuProviderIdResolver.GetMovieScopes(movie).SequenceEqual(new BaseItem[] { movie }),
                "Movie exact matching must inspect only the Movie");
            Assert(DanmuProviderIdResolver.GetSeasonScopes(season).SequenceEqual(new BaseItem[] { season }),
                "Season exact matching must inspect only the Season");
            Assert(DanmuProviderIdResolver.GetEpisodeScopes(episode, season)
                    .SequenceEqual(new BaseItem[] { episode, season }),
                "Episode exact matching must inspect Episode before its Season");

            series.ProviderIds["ScopedID"] = "series-value";
            var scraper = new FakeScraper("ScopedID", null, false,
                new Dictionary<string, ScraperMedia>
                {
                    ["series-value"] = new ScraperMedia { Id = "series-value" },
                });
            var decision = DanmuProviderIdResolver.ResolveAsync(
                    new[] { scraper }, new BaseItem[] { season, series }, null)
                .GetAwaiter().GetResult();
            Assert(decision.Candidate == null && scraper.MediaCalls == 0,
                "the resolver must reject Series scopes even when a caller accidentally supplies one");

            season.ProviderIds["ScopedID"] = "series-value";
            season.ProviderIds["ScopedIDManual"] = "series-manual";
            season.ProviderIds["Other"] = "keep";
            series.ProviderIds["ScopedIDManual"] = "series-manual";
            var equalLocalPreserved = DanmuProviderIdResolver.GetItemLocalProviderIds(
                season, series, new[] { scraper });
            Assert(equalLocalPreserved["ScopedID"] == "series-value" &&
                   equalLocalPreserved["ScopedIDManual"] == "series-manual" &&
                   equalLocalPreserved["Other"] == "keep",
                "a Season ID must remain eligible even when its value equals an ignored Series ID");

            var later = new FakeScraper("LaterID", null, false,
                new Dictionary<string, ScraperMedia>
                {
                    ["later-value"] = new ScraperMedia { Id = "later-value" },
                });
            season.ProviderIds["LaterID"] = "later-value";
            var equalValueDecision = DanmuProviderIdResolver.ResolveAsync(
                    new AbstractScraper[] { scraper, later },
                    DanmuProviderIdResolver.GetSeasonScopes(season), null, series)
                .GetAwaiter().GetResult();
            Assert(equalValueDecision.Scraper == scraper &&
                   equalValueDecision.Candidate?.Id == "series-value" &&
                   scraper.MediaCalls == 1 && later.MediaCalls == 0,
                "configured provider order must retain an item-local Season ID that equals the Series value");
            season.ProviderIds["ScopedID"] = "season-value";
            season.ProviderIds["ScopedIDManual"] = "season-manual";
            var localPreserved = DanmuProviderIdResolver.GetItemLocalProviderIds(
                season, series, new[] { scraper });
            Assert(localPreserved["ScopedID"] == "season-value" &&
                   localPreserved["ScopedIDManual"] == "season-manual",
                "a distinct Season ordinary or manual ID must remain eligible");

            var repositoryRoot = Path.GetFullPath(Path.Combine(
                AppContext.BaseDirectory, "..", "..", "..", ".."));
            var controller = File.ReadAllText(Path.Combine(
                repositoryRoot, "Core", "Controllers", "DanmuController.cs"));
            var library = File.ReadAllText(Path.Combine(repositoryRoot, "LibraryManagerEventsHelper.cs"));
            Assert(controller.Contains("latest, authoritativeParentSeries, scrapers") &&
                   controller.Contains("authoritativeSeries).ConfigureAwait(false)") &&
                   controller.Contains("item.ProviderIds = DanmuProviderIdResolver.GetItemLocalProviderIds(") &&
                   library.Contains("currentItem ?? season, authoritativeSeries, scrapers") &&
                   library.Contains("updateItem.ProviderIds = DanmuProviderIdResolver.GetItemLocalProviderIds("),
                "Season manual binding, automatic import, and metadata writes must all use item-local IDs");
        }

        private static void DiscoversCandidatesWithBoundedTitleClauses()
        {
            const string title = "爱书的下克上：为了成为图书管理员不择手段！";
            var clauses = DanmuTitleClauseExtractor.Extract(title, new[] { title });
            Assert(clauses.SequenceEqual(new[] { "爱书的下克上", "为了成为图书管理员不择手段" }),
                "explicit Chinese punctuation should yield bounded meaningful clauses");
            Assert(DanmuTitleClauseExtractor.Extract("动画：A：正片：有效标题", null)
                    .SequenceEqual(new[] { "有效标题" }),
                "short and generic fragments must not create search rounds");
            Assert(DanmuTitleClauseExtractor.ExtractProviderAliases(
                    new[] { "小书痴的下克上 〜为了成为图书管理员而不择手段〜 第三季" },
                    new[] { title })
                    .SequenceEqual(new[] { "小书痴的下克上", "为了成为图书管理员而不择手段" }),
                "a related provider title should yield bounded season-suffix-free aliases without a static dictionary");

            var preferred = new FakeScraper("PreferredID", null, false, null, null,
                new Dictionary<string, List<ScraperSearchInfo>>(StringComparer.OrdinalIgnoreCase)
                {
                    ["为了成为图书管理员不择手段"] = new List<ScraperSearchInfo>
                    {
                        new ScraperSearchInfo
                        {
                            Id = "preferred-clause",
                            Name = title,
                            Year = 2022,
                            EpisodeSize = 12,
                        },
                    },
                });
            var alreadyConfident = new FakeScraper("LaterID", null, false, null, null,
                new Dictionary<string, List<ScraperSearchInfo>>(StringComparer.OrdinalIgnoreCase)
                {
                    [title] = new List<ScraperSearchInfo>
                    {
                        new ScraperSearchInfo
                        {
                            Id = "later-standard",
                            Name = title,
                            Year = 2022,
                            EpisodeSize = 12,
                        },
                    },
                });
            var search = DanmuMatchSearchEngine.SearchSeasonAsync(
                    new AbstractScraper[] { preferred, alreadyConfident },
                    title, title, 2022, 12, null, null)
                .GetAwaiter().GetResult();
            Assert(search.Candidates.Any(x => x.Id == "preferred-clause") &&
                   DanmuMatchScorer.SelectAutoCandidate(search.Candidates)?.Id == "preferred-clause",
                "a confident clause result from the earlier configured provider must participate in normal scoring");
            Assert(!alreadyConfident.ApiKeywords.Contains("为了成为图书管理员不择手段"),
                "a provider with a confident standard result should not receive clause fallback");

            var aliasProvider = new FakeScraper("AliasID", null, false, null, null,
                new Dictionary<string, List<ScraperSearchInfo>>(StringComparer.OrdinalIgnoreCase)
                {
                    [title] = new List<ScraperSearchInfo>
                    {
                        new ScraperSearchInfo
                        {
                            Id = "15634",
                            Name = "小书痴的下克上 〜为了成为图书管理员而不择手段〜 第三季",
                            Year = 2022,
                            EpisodeSize = 10,
                        },
                    },
                    ["小书痴的下克上"] = new List<ScraperSearchInfo>
                    {
                        new ScraperSearchInfo
                        {
                            Id = "15293",
                            Name = "小书痴的下克上 〜为了成为图书管理员而不择手段〜 第二季",
                            Year = 2020,
                            EpisodeSize = 12,
                        },
                    },
                });
            var aliasSearch = DanmuMatchSearchEngine.SearchSeasonAsync(
                    new[] { aliasProvider }, title, "第 2 季", 2026, 12, null, null)
                .GetAwaiter().GetResult();
            Assert(aliasProvider.ApiKeywords.Contains("小书痴的下克上") &&
                   aliasSearch.Candidates.Any(x => x.Id == "15293"),
                "provider-local second-hop aliases must discover otherwise hidden seasons without changing full-title scoring");

            var custom = new FakeScraper("CustomID", null, false, null, null,
                new Dictionary<string, List<ScraperSearchInfo>>());
            DanmuMatchSearchEngine.SearchSeasonAsync(
                    new[] { custom }, title, title, 2022, 12, "只搜索这个词", null)
                .GetAwaiter().GetResult();
            Assert(custom.ApiKeywords.SequenceEqual(new[] { "只搜索这个词" }),
                "an explicit custom keyword must remain isolated from derived clauses");
        }

        private static void NormalizesDandanStandaloneSeasonOrdinals()
        {
            var cumulative = Enumerable.Range(15, 12)
                .Select(number => new Emby.Plugin.Danmu.Scraper.Dandan.Entity.Episode
                {
                    EpisodeId = 152930000 + number,
                    EpisodeNumber = number.ToString(),
                    EpisodeTitle = "第" + number + "话",
                })
                .ToList();
            cumulative.Insert(3, new Emby.Plugin.Danmu.Scraper.Dandan.Entity.Episode
            {
                EpisodeId = 999,
                EpisodeNumber = "PV",
                EpisodeTitle = "正式预告",
            });

            var mapped = DandanSeasonEpisodeMapper.Map(cumulative, true);
            Assert(mapped.Count == 12 && mapped.Select(x => x.EpisodeNumber).SequenceEqual(
                       Enumerable.Range(1, 12).Select(x => (int?)x)),
                "Dandan standalone seasons must filter non-main entries before local 1..N normalization");
            Assert(mapped[0].Id == "152930015" && mapped[11].Id == "152930026" &&
                   mapped.All(x => x.Id == x.CommentId),
                "normalization must retain every real Dandan EpisodeId");
        }

        private static void EnforcesBilibiliPgcIdentifierPolicy()
        {
            Assert(BilibiliPgcIdPolicy.SupportsExactItem(new Season()) &&
                   BilibiliPgcIdPolicy.SupportsExactItem(new Episode()) &&
                   BilibiliPgcIdPolicy.SupportsExactItem(new Movie()) &&
                   !BilibiliPgcIdPolicy.SupportsExactItem(new Series()),
                "Bilibili exact matching must support Season/Movie/Episode but never Series");
            Assert(BilibiliPgcIdPolicy.IsPositiveNumericId("46089") &&
                   BilibiliPgcIdPolicy.IsPositiveNumericId("779775") &&
                   !BilibiliPgcIdPolicy.IsPositiveNumericId("BV1test") &&
                   !BilibiliPgcIdPolicy.IsPositiveNumericId("123,456"),
                "durable Bilibili identifiers must be positive PGC numeric IDs");
            var movieMedia = new ScraperMedia
            {
                Id = "779775",
                CommentId = "779775",
                Episodes = new List<ScraperEpisode>
                {
                    new ScraperEpisode { Id = "779775", CommentId = "100,200" },
                },
            };
            Assert(BilibiliPgcIdPolicy.ResolveMovieEpisodeId(movieMedia) == "779775",
                "a PGC Movie must persist ep_id rather than its transient aid,cid tuple");

            var repositoryRoot = Path.GetFullPath(Path.Combine(
                AppContext.BaseDirectory, "..", "..", "..", ".."));
            var bilibili = File.ReadAllText(Path.Combine(
                repositoryRoot, "Scraper", "Bilibili", "Bilibili.cs"));
            Assert(bilibili.Contains("if (isMovieItemType || isEpisodeItemType)") &&
                   bilibili.Contains("exactEpisode.Id != numericId") &&
                   bilibili.Contains("_api.GetEpisodeAsync(numericId"),
                "Movie and Episode exact matching must validate their own ep_id instead of treating it as season_id");
        }

        private static void ExposesBilibiliAndMgtvExternalIds()
        {
            var biliSeason = new Emby.Plugin.Danmu.Scraper.Bilibili.ExternalId.SeasonExternalId();
            var biliMovie = new Emby.Plugin.Danmu.Scraper.Bilibili.ExternalId.MovieExternalId();
            var biliEpisode = new Emby.Plugin.Danmu.Scraper.Bilibili.ExternalId.EpisodeExternalId();
            var mgtvSeason = new Emby.Plugin.Danmu.Scrapers.Mgtv.ExternalId.SeasonExternalId();
            Assert(biliSeason.Supports(new Season()) && biliSeason.Supports(new Series()) &&
                   biliMovie.Supports(new Movie()) && biliEpisode.Supports(new Episode()) &&
                   mgtvSeason.Supports(new Season()) && mgtvSeason.Supports(new Series()),
                "Bilibili and Mgtv external IDs must be visible on their item editors, including display-only Series fields");
            Assert(biliSeason.UrlFormatString == "#" && biliMovie.UrlFormatString == "#" &&
                   biliEpisode.UrlFormatString == "#",
                "Bilibili polymorphic PGC IDs must not be formatted as one misleading public URL");
        }

        private static void PreservesSeasonSuccessPersistenceContract()
        {
            var repositoryRoot = Path.GetFullPath(Path.Combine(
                AppContext.BaseDirectory, "..", "..", "..", ".."));
            var controller = File.ReadAllText(Path.Combine(repositoryRoot, "Core", "Controllers", "DanmuController.cs"));
            var library = File.ReadAllText(Path.Combine(repositoryRoot, "LibraryManagerEventsHelper.cs"));
            Assert(controller.Contains("PersistProviderIdAfterAcceptedOutcome(episode, outcome)") &&
                   controller.Contains("PersistSeasonProviderIdAfterAcceptedOutcome(") &&
                   controller.Contains("task.SeasonProviderWriteGeneration") &&
                   controller.Contains("task.SeasonProviderCommitted") &&
                   controller.Contains("if (request.Manual)") &&
                   controller.Contains("SaveManualBindingAsync(season"),
                "tracked Season downloads must write each successful Episode and commit the Season only from accepted file success");
            Assert(library.Contains("anyFilePersisted = true") &&
                   library.Contains("SaveAutomaticSeasonProviderId(") &&
                   library.Contains("MarkStarted(GetProviderWriteKey(item, providerId), generation)") &&
                   library.Contains("_scraperManager.AllWithNoEnabled()") &&
                   library.Contains("DanmuProviderIdWritePolicy.BuildSuccessfulWrite(") &&
                   library.Contains("updateItem is Season || updateItem is Episode"),
                "automatic import, latest-started protection, and all-registered ordinary-ID cleanup must share the success-gated persistence path");
        }

        private static void PreservesSeriesPreviewProviderIdContract()
        {
            var repositoryRoot = Path.GetFullPath(Path.Combine(
                AppContext.BaseDirectory, "..", "..", "..", ".."));
            var controller = File.ReadAllText(Path.Combine(
                repositoryRoot, "Core", "Controllers", "DanmuController.cs"));
            var seriesStart = controller.IndexOf("else if (item is Series series)", StringComparison.Ordinal);
            var seriesEnd = controller.IndexOf("if (request.SeasonNumber.HasValue", seriesStart, StringComparison.Ordinal);
            var seriesPreview = controller.Substring(seriesStart, seriesEnd - seriesStart);
            Assert(seriesPreview.Contains("_libraryManager.GetItemList(new InternalItemsQuery") &&
                   seriesPreview.Contains("ParentIds = new[] { series.InternalId }") &&
                   seriesPreview.Contains("IncludeItemTypes = new[] { \"Season\" }") &&
                   seriesPreview.Contains("Recursive = false") &&
                   !seriesPreview.Contains("DtoOptions"),
                "Series match preview must enumerate direct, non-projected library Seasons with ProviderIds intact");
            Assert(controller.Contains("item is Series,\n                    item as Series).ConfigureAwait(false)") &&
                   controller.Contains("bool preserveProvidedSeason = false") &&
                   controller.Contains("Series explicitParentSeries = null") &&
                   controller.Contains("_libraryManager.GetItemById(parentSeries.InternalId)") &&
                   controller.Contains("? season\n                : _libraryManager.GetItemById(season.Id)"),
                "Series preview must pass its entry Series explicitly while direct Season/Episode paths refresh the parent by InternalId");

            var scraper = new FakeScraper("SeriesSeasonID", null, false, new Dictionary<string, ScraperMedia>
            {
                ["series-season-id"] = new ScraperMedia
                {
                    Id = "series-season-id",
                    Episodes = new List<ScraperEpisode>
                    {
                        new ScraperEpisode { Id = "episode", CommentId = "episode" },
                    },
                },
            });
            var providerSeason = new Season { Name = "Series preview season" };
            providerSeason.ProviderIds["SeriesSeasonID"] = "series-season-id";
            var decision = DanmuProviderIdResolver.ResolveAsync(
                    new[] { scraper }, new BaseItem[] { providerSeason }, null)
                .GetAwaiter().GetResult();
            Assert(decision.Candidate?.Id == "series-season-id" &&
                   decision.MatchOrigin == "provider-id" &&
                   decision.ResolvedScopeType == "Season",
                "a Series-entry Season retaining ProviderIds must take provider-ID precedence before scoring");
        }

        private static void ProjectsProviderIdMetadataWithoutSearchOrScoring()
        {
            var resolved = new ScraperMedia
            {
                Id = "exact-upstream-id",
                Title = "Upstream-only title",
                Year = 2024,
                Category = "Upstream category",
                EpisodeCount = 26,
                Episodes = new List<ScraperEpisode>
                {
                    new ScraperEpisode { Id = "1", CommentId = "1", Title = "Episode 1" },
                    new ScraperEpisode { Id = "2", CommentId = "2", Title = "Episode 2" },
                },
            };
            var scraper = new FakeScraper("ExactID", new List<ScraperSearchInfo>(), false,
                new Dictionary<string, ScraperMedia>
                {
                    ["movie"] = resolved,
                    ["series"] = resolved,
                    ["season"] = resolved,
                    ["missing"] = null,
                },
                new Dictionary<string, ScraperEpisode>
                {
                    ["episode"] = new ScraperEpisode
                    {
                        Id = "episode",
                        CommentId = "episode-comment",
                        Title = "Upstream episode title",
                    },
                });

            foreach (var scope in new BaseItem[]
            {
                new Movie { Name = "local movie" },
                new Season { Name = "local season" },
            })
            {
                scope.ProviderIds["ExactID"] = scope is Movie ? "movie" :
                    "season";
                var decision = DanmuProviderIdResolver.ResolveAsync(
                        new[] { scraper }, new[] { scope }, null)
                    .GetAwaiter().GetResult();
                Assert(decision.Candidate?.Id == "exact-upstream-id" &&
                       decision.Candidate.Name == "Upstream-only title" &&
                       decision.Candidate.Year == 2024 &&
                       decision.Candidate.Category == "Upstream category" &&
                       decision.Candidate.EpisodeSize == 26,
                    "exact ProviderId candidates must project only declared upstream metadata");
            }

            var ignoredSeries = new Series { Name = "local series" };
            ignoredSeries.ProviderIds["ExactID"] = "series";
            var ignoredSeriesDecision = DanmuProviderIdResolver.ResolveAsync(
                    new[] { scraper }, new BaseItem[] { ignoredSeries }, null)
                .GetAwaiter().GetResult();
            Assert(ignoredSeriesDecision.Candidate == null,
                "Series metadata may be displayed but must never become an exact-match candidate");

            var episode = new Episode { Name = "local episode" };
            episode.ProviderIds["ExactID"] = "episode";
            var directEpisode = DanmuProviderIdResolver.ResolveAsync(
                    new[] { scraper }, new BaseItem[] { episode }, null)
                .GetAwaiter().GetResult();
            Assert(directEpisode.Candidate?.Name == "Upstream episode title" &&
                   directEpisode.Candidate.EpisodeSize == 1 &&
                   directEpisode.Media?.Episodes.Count == 1,
                "direct Episode identifiers must expose the direct upstream title and one-item media result");

            var fallback = new FakeScraper("FallbackID", null, false,
                new Dictionary<string, ScraperMedia>
                {
                    ["fallback"] = new ScraperMedia
                    {
                        Id = "fallback",
                        Episodes = new List<ScraperEpisode>
                        {
                            new ScraperEpisode { Id = "1", CommentId = "1" },
                            new ScraperEpisode { Id = "2", CommentId = "2" },
                            new ScraperEpisode { Id = "not-downloadable" },
                        },
                    },
                });
            var fallbackScope = new Season { Name = "local title must not leak" };
            fallbackScope.ProviderIds["FallbackID"] = "fallback";
            var fallbackDecision = DanmuProviderIdResolver.ResolveAsync(
                    new[] { fallback }, new BaseItem[] { fallbackScope }, null)
                .GetAwaiter().GetResult();
            Assert(fallbackDecision.Candidate?.Name == "标题未知" &&
                   fallbackDecision.Candidate.Year == null &&
                   fallbackDecision.Candidate.Category == string.Empty &&
                   fallbackDecision.Candidate.EpisodeSize == 2,
                "missing detail fields must remain unknown and count only usable resolved episodes");

            var unresolvedScope = new Movie { Name = "unresolved local movie" };
            unresolvedScope.ProviderIds["ExactID"] = "missing";
            var unresolved = DanmuProviderIdResolver.ResolveAsync(
                    new[] { scraper }, new BaseItem[] { unresolvedScope }, null)
                .GetAwaiter().GetResult();
            Assert(unresolved.Candidate == null && unresolved.Diagnostics.Any(x => x == "provider-id-unresolved:ExactID") &&
                   scraper.SearchCalls == 0,
                "resolved and unresolved ProviderId detail paths must not invoke search or scoring");
        }

        private static void PreservesProviderDetailAdapterMetadataContracts()
        {
            var repositoryRoot = Path.GetFullPath(Path.Combine(
                AppContext.BaseDirectory, "..", "..", "..", ".."));
            var dandan = File.ReadAllText(Path.Combine(repositoryRoot, "Scraper", "Dandan", "Dandan.cs"));
            var bilibili = File.ReadAllText(Path.Combine(repositoryRoot, "Scraper", "Bilibili", "Bilibili.cs"));
            var iqiyi = File.ReadAllText(Path.Combine(repositoryRoot, "Scraper", "Iqiyi", "Iqiyi.cs"));
            var mgtv = File.ReadAllText(Path.Combine(repositoryRoot, "Scraper", "Mgtv", "Mgtv.cs"));
            var tencent = File.ReadAllText(Path.Combine(repositoryRoot, "Scraper", "Tencent", "Tencent.cs"));
            var youku = File.ReadAllText(Path.Combine(repositoryRoot, "Scraper", "Youku", "Youku.cs"));

            Assert(dandan.Contains("media.Title = anime.AnimeTitle") &&
                   dandan.Contains("media.Year = anime.Year") &&
                   dandan.Contains("media.Category = anime.TypeDescription") &&
                   dandan.Contains("DandanSeasonEpisodeMapper.Map(") &&
                   dandan.Contains("? media.Episodes.Count") &&
                   dandan.Contains(": anime.EpisodeCount"),
                "Dandan exact Anime details must retain their explicit upstream metadata");
            Assert(bilibili.Contains("Title = videoInfo.Title") &&
                   bilibili.Contains("Year = videoInfo.Pubdate") &&
                   bilibili.Contains("EpisodeCount = videoInfo.VideosCount") &&
                   bilibili.Contains("GetSeasonDetailAsync(numericId") &&
                   bilibili.Contains("Title = !string.IsNullOrWhiteSpace(seasonDetail?.Title)") &&
                   bilibili.Contains("seasonDetail?.Total > 0") &&
                   !bilibili.Contains("Title = ep.Title ?? item.Name") &&
                   !bilibili.Contains("Title = item?.Name"),
                "Bilibili exact details must retain known values without inventing a category or local title");
            Assert(iqiyi.Contains("media.Title = video.VideoName") &&
                   iqiyi.Contains("media.Category = video.channelName") &&
                   iqiyi.Contains("media.EpisodeCount = video.VideoCount") &&
                   !iqiyi.Contains("media.Year ="),
                "iQiyi exact details must retain supported fields while leaving year unknown");
            foreach (var source in new[] { mgtv, tencent, youku })
            {
                Assert(source.Contains("media.EpisodeCount = media.Episodes.Count") &&
                       !source.Contains("media.Title =") &&
                       !source.Contains("media.Year =") &&
                       !source.Contains("media.Category ="),
                    "providers with episode-list-only exact details must expose the usable count and keep unsupported metadata unknown");
            }
        }

        private static void RequiresVerifiedDirectEpisodeDetailsAndUsesResolvedUgcCounts()
        {
            var repositoryRoot = Path.GetFullPath(Path.Combine(
                AppContext.BaseDirectory, "..", "..", "..", ".."));
            var dandan = File.ReadAllText(Path.Combine(repositoryRoot, "Scraper", "Dandan", "Dandan.cs"));
            var bilibili = File.ReadAllText(Path.Combine(repositoryRoot, "Scraper", "Bilibili", "Bilibili.cs"));
            var bilibiliApi = File.ReadAllText(Path.Combine(repositoryRoot, "Scraper", "Bilibili", "BilibiliApi.cs"));
            var iqiyi = File.ReadAllText(Path.Combine(repositoryRoot, "Scraper", "Iqiyi", "Iqiyi.cs"));
            var mgtv = File.ReadAllText(Path.Combine(repositoryRoot, "Scraper", "Mgtv", "Mgtv.cs"));
            var tencent = File.ReadAllText(Path.Combine(repositoryRoot, "Scraper", "Tencent", "Tencent.cs"));
            var youku = File.ReadAllText(Path.Combine(repositoryRoot, "Scraper", "Youku", "Youku.cs"));

            Assert(dandan.Contains("Dandan's existing detail endpoint accepts Anime IDs") &&
                   !dandan.Contains("return new ScraperEpisode() { Id = id, CommentId = id }"),
                "Dandan Episode ProviderIds must fail closed when no exact episode detail endpoint exists");
            Assert(mgtv.Contains("GetVideoAsync(seasonId") &&
                   mgtv.Contains("string.Equals(x.VideoId, id") &&
                   tencent.Contains("GetVideoAsync(seasonId") &&
                   tencent.Contains("string.Equals(x.Vid, id"),
                "MGTV and Tencent Episode ProviderIds must be found in a remotely resolved same-provider collection");
            Assert(youku.Contains("GetEpisodeAsync(id") &&
                   youku.Contains("expectedId = id.Replace") &&
                   iqiyi.Contains("GetVideoBaseAsync(id") && iqiyi.Contains("if (video == null)"),
                "Youku and iQiyi Episode ProviderIds must use exact remote detail calls");
            Assert(bilibili.Contains("GetVideoByAidAsync(tupleAid") &&
                   bilibili.Contains("tupleVideo?.Aid != tupleAid") &&
                   bilibili.Contains("FirstOrDefault(x => x.Cid == tupleCid)") &&
                   bilibili.Contains("matchingUgcEpisode") &&
                   bilibiliApi.Contains("x/web-interface/view?aid={aid}") &&
                   bilibili.Contains("GetEpisodeAsync(numericId") &&
                   bilibili.Contains("上游未确认该 ep_id；返回 null") &&
                   bilibili.Contains("scraperMedia.EpisodeCount = scraperMedia.Episodes.Count"),
                "Bilibili must verify saved aid,cid tuples by official AID detail and count UGC matches from the resolved collection");

            var noDetailScraper = new FakeScraper("NoDetailID", null, false, null,
                new Dictionary<string, ScraperEpisode> { ["unverified"] = null });
            var localEpisode = new Episode { Name = "local-only episode" };
            localEpisode.ProviderIds["NoDetailID"] = "unverified";
            var decision = DanmuProviderIdResolver.ResolveAsync(
                    new[] { noDetailScraper }, new BaseItem[] { localEpisode }, null)
                .GetAwaiter().GetResult();
            Assert(decision.Candidate == null &&
                   decision.Diagnostics.Any(x => x == "provider-id-unresolved:NoDetailID") &&
                   noDetailScraper.MediaCalls == 0 && noDetailScraper.SearchCalls == 0,
                "an unverified direct Episode ID must not become an exact candidate or trigger search");

            var tupleScraper = new FakeScraper("BilibiliID", null, false, null,
                new Dictionary<string, ScraperEpisode>
                {
                    ["123,456"] = new ScraperEpisode
                    {
                        Id = "123,456",
                        CommentId = "123,456",
                        Title = "Verified upstream part",
                        EpisodeNumber = 2,
                    },
                });
            var tupleEpisode = new Episode { Name = "local tuple episode", IndexNumber = 2 };
            tupleEpisode.ProviderIds["BilibiliID"] = "123,456";
            var tupleDecision = DanmuProviderIdResolver.ResolveAsync(
                    new[] { tupleScraper }, new BaseItem[] { tupleEpisode }, null)
                .GetAwaiter().GetResult();
            Assert(tupleDecision.Candidate?.Id == "123,456" &&
                   tupleDecision.Candidate.Name == "Verified upstream part" &&
                   tupleDecision.Media?.Episodes.Single().Id == "123,456" &&
                   tupleDecision.Media.Episodes.Single().CommentId == "123,456" &&
                   tupleScraper.MediaCalls == 0 && tupleScraper.SearchCalls == 0,
                "a verified Bilibili aid,cid episode must round-trip through exact candidate creation without media lookup or search");
        }

        private static void MapsEpisodeSourceNumbersSafely()
        {
            Assert(DanmuEpisodeMatchHelper.SuggestSourceEpisodeNumber(3, 12) == 3,
                "the local episode number should be the default source suggestion when available");
            Assert(!DanmuEpisodeMatchHelper.SuggestSourceEpisodeNumber(13, 12).HasValue,
                "a source suggestion outside the candidate episode list should be omitted");
            Assert(!DanmuEpisodeMatchHelper.IsValidSourceEpisodeNumber(0, 12) &&
                   DanmuEpisodeMatchHelper.IsValidSourceEpisodeNumber(12, 12),
                "source episode validation should accept only positive existing numbers");

            var sourceEpisodes = new List<ScraperEpisode>
            {
                new ScraperEpisode { CommentId = "episode-1", EpisodeNumber = 1 },
                new ScraperEpisode { CommentId = "episode-3", EpisodeNumber = 3 },
            };
            Assert(DanmuEpisodeMatchHelper.SuggestSourceEpisodeNumber(1, sourceEpisodes) == 1 &&
                   DanmuEpisodeMatchHelper.SuggestSourceEpisodeNumber(2, sourceEpisodes) == null &&
                   DanmuEpisodeMatchHelper.SuggestSourceEpisodeNumber(3, sourceEpisodes) == 3 &&
                   DanmuEpisodeMatchHelper.TryGetSourceEpisode(sourceEpisodes, 3, out var third) &&
                   third.CommentId == "episode-3",
                "explicit provider numbering should preserve a real episode gap instead of mapping episode 2 by list position");

            var legacyEpisodes = new List<ScraperEpisode>
            {
                new ScraperEpisode { CommentId = "legacy-1" },
                new ScraperEpisode { CommentId = "legacy-2" },
            };
            Assert(DanmuEpisodeMatchHelper.TryGetSourceEpisode(legacyEpisodes, 2, out var legacySecond) &&
                   legacySecond.CommentId == "legacy-2",
                "episode collections with no reliable numbering should retain the legacy positional fallback");
        }

        private static void DeserializesBilibiliExactVideoDetails()
        {
            const string officialDetailJson =
                "{\"bvid\":\"BV1test\",\"aid\":123,\"videos\":2,\"title\":\"Exact video\",\"pages\":[{\"cid\":456,\"page\":2,\"part\":\"Exact part\"}],\"ugc_season\":{\"id\":9,\"title\":\"UGC season\",\"sections\":[{\"id\":10,\"episodes\":[{\"id\":11,\"aid\":123,\"cid\":789,\"title\":\"UGC episode\"}]}]}}";
            var video = JsonSerializer.Deserialize<Emby.Plugin.Danmu.Scraper.Bilibili.Entity.Video>(officialDetailJson,
                new JsonSerializerOptions { PropertyNameCaseInsensitive = true });

            Assert(video?.VideosCount == 2 && video.Pages?.Single().Cid == 456 &&
                   video.Pages.Single().PartName == "Exact part" &&
                   video.UgcSeason?.Sections?.Single().Episodes?.Single().AId == 123 &&
                   video.UgcSeason.Sections.Single().Episodes.Single().CId == 789 &&
                   video.UgcSeason.Sections.Single().Episodes.Single().Title == "UGC episode",
                "official Bilibili AID/BVID detail JSON must retain videos, pages.part, and ugc_season episode fields");
        }

        private static void DeserializesBilibiliExactSeasonDetails()
        {
            const string officialDetailJson =
                "{\"code\":0,\"result\":{\"season_id\":46089,\"title\":\"葬送的芙莉莲\",\"season_title\":\"葬送的芙莉莲 第一季\",\"total\":28,\"publish\":{\"pub_time\":\"2023-09-29 23:00:00\"}}}";
            var detail = JsonSerializer.Deserialize<ApiResult<VideoSeasonDetail>>(officialDetailJson,
                new JsonSerializerOptions { PropertyNameCaseInsensitive = true });

            Assert(detail?.Code == 0 && detail.Result?.SeasonId == 46089 &&
                   detail.Result.Title == "葬送的芙莉莲" &&
                   detail.Result.SeasonTitle == "葬送的芙莉莲 第一季" &&
                   detail.Result.Total == 28 &&
                   detail.Result.Publish?.PubTime == "2023-09-29 23:00:00",
                "official Bilibili PGC season detail JSON must retain title, season_title, publish.pub_time, and declared total");

            var repositoryRoot = Path.GetFullPath(Path.Combine(
                AppContext.BaseDirectory, "..", "..", "..", ".."));
            var biliSource = File.ReadAllText(Path.Combine(repositoryRoot, "Scraper", "Bilibili", "Bilibili.cs"));
            var apiSource = File.ReadAllText(Path.Combine(repositoryRoot, "Scraper", "Bilibili", "BilibiliApi.cs"));
            Assert(biliSource.Contains("GetSeasonDetailAsync(numericId") &&
                   biliSource.Contains("seasonDetail?.Total > 0") &&
                   biliSource.Contains("TryGetYearFromSeasonDetail"),
                "exact Bilibili Season resolution must use same-ID detail metadata and its declared total");
            Assert(biliSource.Contains("VideoSeasonDetail seasonDetail = null") &&
                   biliSource.Contains("exact metadata detail unavailable; retaining ep/list media") &&
                   biliSource.Contains("must not discard ep/list's exact downloadable media"),
                "failed Bilibili Season display-detail enrichment must preserve exact ep/list media");
            Assert(apiSource.Contains("pgc/view/web/season?season_id={seasonId}") &&
                   !apiSource.Contains("SearchAsync(seasonId"),
                "Bilibili Season metadata enrichment must use only the exact season detail endpoint");
        }

        private static void DeserializesAndNormalizesBilibiliEpisodes()
        {
            const string json = "{\"season_id\":46089,\"episodes\":[" +
                                "{\"id\":101,\"title\":\"1\",\"long_title\":\"第1集预告\",\"badge\":\"预告\",\"badge_type\":1,\"section_type\":1,\"duration\":35000}," +
                                "{\"id\":201,\"title\":\"1\",\"long_title\":\"冒险开始\",\"badge_type\":0,\"section_type\":0,\"duration\":1500000}," +
                                "{\"id\":102,\"title\":\"2\",\"badge\":\"预告\",\"badge_type\":1,\"section_type\":1,\"duration\":40000}," +
                                "{\"id\":202,\"title\":\"2\",\"badge_type\":0,\"section_type\":0,\"duration\":1490000}]}";
            var season = JsonSerializer.Deserialize<VideoSeason>(json);
            Assert(season.SeasonId == 46089 && season.Episodes[0].SectionType == 1, "underscored Bilibili fields should deserialize explicitly");

            var normalized = BilibiliEpisodeNormalizer.Normalize(season.Episodes);
            Assert(normalized.Count == 2, "interleaved previews should be removed");
            Assert(normalized[0].Id == 201 && normalized[1].Id == 202, "full episodes should retain canonical numeric order");
        }

        private static void ClassifiesOnlyExplicitNonMainTitles()
        {
            Assert(EpisodeContentClassifier.IsExplicitNonMain("【预告】第8集"), "explicit preview marker should be excluded");
            Assert(EpisodeContentClassifier.IsExplicitNonMain("第8集预告"), "a Chinese preview suffix should be excluded");
            Assert(EpisodeContentClassifier.IsExplicitNonMain("PV 01"), "explicit PV marker should be excluded");
            Assert(!EpisodeContentClassifier.IsExplicitNonMain("第1集"), "ordinary episode title should remain");
            Assert(!EpisodeContentClassifier.IsExplicitNonMain("PVZ大战"), "PV letters inside a word should not be treated as a marker");
        }

        private static void ResolvesDandanCredentialsByCompletePair()
        {
            var configured = DandanCredentialResolver.Resolve(
                " configured-id ", " configured-secret ",
                "environment-id", "environment-secret",
                "legacy-id", "legacy-secret");
            Assert(configured.ApiId == "configured-id" && configured.ApiSecret == "configured-secret",
                "configured Dandan credentials should win and be trimmed");
            Assert(configured.Source == "插件配置", "credential source should identify plugin configuration");

            var environment = DandanCredentialResolver.Resolve(
                "", "", " environment-id ", " environment-secret ", "legacy-id", "legacy-secret");
            Assert(environment.ApiId == "environment-id" && environment.Source == "环境变量",
                "environment pair should be used when configuration is empty");

            var legacy = DandanCredentialResolver.Resolve("", "", "", "", " legacy-id ", " legacy-secret ");
            Assert(legacy.ApiId == "legacy-id" && legacy.Source == "内置配置",
                "legacy pair should remain a final compatibility fallback");
        }

        private static void RejectsIncompleteDandanCredentialsWithoutLeakingValues()
        {
            var message = CaptureCredentialError("LEAK_ID", "", "environment-id", "environment-secret");
            Assert(message.Contains("不完整"), "partial configured credentials should report an incomplete pair");
            Assert(!message.Contains("LEAK_ID"), "credential errors must not include the API ID");

            message = CaptureCredentialError("", "LEAK_SECRET", "environment-id", "environment-secret");
            Assert(!message.Contains("LEAK_SECRET"), "credential errors must not include the API Secret");

            message = CaptureCredentialError("", "", "", "");
            Assert(message.Contains("缺少"), "an empty credential chain should report missing credentials");
        }

        private static string CaptureCredentialError(
            string configuredId,
            string configuredSecret,
            string environmentId,
            string environmentSecret)
        {
            try
            {
                DandanCredentialResolver.Resolve(
                    configuredId, configuredSecret, environmentId, environmentSecret, "", "");
                throw new InvalidOperationException("expected credential resolution to fail");
            }
            catch (InvalidOperationException ex)
            {
                return ex.Message;
            }
        }

        private static void PreservesLegacyDandanApiDefaults()
        {
            var serializer = new XmlSerializer(typeof(DandanOption));
            DandanOption option;
            using (var reader = new StringReader("<DandanOption />"))
            {
                option = (DandanOption)serializer.Deserialize(reader);
            }

            Assert(!option.UseProxyApi,
                "legacy Dandan configuration without an API mode should remain in custom API mode");
            Assert(option.ProxyCorsUrl == string.Empty,
                "legacy Dandan configuration should default to an empty proxy CORS prefix");
            Assert(option.WithRelatedDanmu && option.ChConvert == 0,
                "adding proxy settings must not change existing Dandan option defaults");
        }

        private static void PreservesSavedManualBindingsUntilForcedSearch()
        {
            var first = new FakeScraper("FirstID", null);
            var saved = new FakeScraper("SavedID", null);
            var providerIds = new Dictionary<string, string>
            {
                ["FirstID"] = "automatic-id",
                ["SavedIDManual"] = "saved-manual-id",
            };

            Assert(DanmuMatchBindingHelper.TryGetSavedManualBinding(
                       false, new[] { first, saved }, providerIds, out var scraper, out var manualId) &&
                   scraper == saved && manualId == "saved-manual-id",
                "Movie and Season previews should prefer an existing explicit manual binding");
            Assert(!DanmuMatchBindingHelper.TryGetSavedManualBinding(
                       true, new[] { first, saved }, providerIds, out _, out _) &&
                   providerIds["SavedIDManual"] == "saved-manual-id",
                "forced search should bypass but not delete the saved manual binding");
        }

        private static void AppliesDuplicateAndForceRefreshPolicy()
        {
            var now = new DateTime(2026, 8, 10, 12, 0, 0, DateTimeKind.Local);
            Assert(DanmuDownloadPolicy.ShouldSkipExistingDanmu(
                       false, true, now.AddDays(-2), now),
                "a recent existing danmu file should produce a duplicate skip");
            Assert(!DanmuDownloadPolicy.ShouldSkipExistingDanmu(
                       true, true, now.AddMinutes(-1), now),
                "force refresh should bypass the duplicate skip policy");
            Assert(!DanmuDownloadPolicy.ShouldSkipExistingDanmu(
                       false, true, now.AddDays(-8), now) &&
                   !DanmuDownloadPolicy.ShouldSkipExistingDanmu(
                       false, false, DateTime.MinValue, now),
                "expired or missing danmu files should remain downloadable");

            var invalidMovie = new ScraperMedia
            {
                Id = string.Empty,
                CommentId = string.Empty,
                Episodes = new List<ScraperEpisode>(),
            };
            Assert(DanmuMovieMatchHelper.ResolveEpisodeLookupId("IqiyiID", invalidMovie) == string.Empty,
                "movie candidate preparation should reject media without a provider playback/comment identifier");
        }

        private static void PreservesSingleEpisodeIsolationAndLegacyTaskShape()
        {
            var seasonBindings = new Dictionary<string, string>
            {
                ["DandanIDManual"] = "season-binding",
            };
            var sources = new List<ScraperEpisode>
            {
                new ScraperEpisode { CommentId = "source-1" },
                new ScraperEpisode { CommentId = "source-2" },
                new ScraperEpisode { CommentId = "source-3" },
            };
            Assert(DanmuEpisodeMatchHelper.TryGetSourceEpisode(sources, 2, out var selected) &&
                   selected.CommentId == "source-2" && sources.Count == 3 &&
                   seasonBindings["DandanIDManual"] == "season-binding",
                "single-Episode selection should isolate the requested source and leave sibling/source collections and Season binding intact");

            var legacySeasonTask = new DanmuDownloadTaskResult
            {
                TaskId = "season-task",
                SeriesId = "series-id",
                SeasonId = "season-id",
                SeasonName = "Season 1",
                Status = "running",
                Episodes = new List<DanmuEpisodeDownloadResult>
                {
                    new DanmuEpisodeDownloadResult { ItemId = "episode-1", EpisodeNumber = 1 },
                    new DanmuEpisodeDownloadResult { ItemId = "episode-2", EpisodeNumber = 2 },
                },
            };
            var json = JsonSerializer.Serialize(legacySeasonTask);
            var roundTrip = JsonSerializer.Deserialize<DanmuDownloadTaskResult>(json);
            Assert(roundTrip.SeasonId == "season-id" && roundTrip.SeriesId == "series-id" &&
                   roundTrip.Episodes.Count == 2 && roundTrip.Status == "running",
                "additive single-target fields must preserve the existing Series/Season task shape");
        }

        private static void MigratesOfficialProxyCorsConfigurationWithoutPersistingItsAddress()
        {
            var serializer = new XmlSerializer(typeof(DandanOption));
            DandanOption Deserialize(string xml)
            {
                using (var reader = new StringReader(xml))
                {
                    return (DandanOption)serializer.Deserialize(reader);
                }
            }

            var legacyEmpty = Deserialize("<DandanOption />");
            var legacyCustom = Deserialize("<DandanOption><ProxyCorsUrl>https://worker.example/cors/</ProxyCorsUrl></DandanOption>");
            var explicitOfficial = Deserialize("<DandanOption><UseOfficialProxyCors>true</UseOfficialProxyCors></DandanOption>");
            var explicitCustom = Deserialize("<DandanOption><UseOfficialProxyCors>false</UseOfficialProxyCors></DandanOption>");

            Assert(DandanApi.ResolveUseOfficialProxyCors(legacyEmpty),
                "a legacy configuration without a custom prefix should migrate to official CORS");
            Assert(!DandanApi.ResolveUseOfficialProxyCors(legacyCustom),
                "a legacy configuration with a custom prefix should preserve custom CORS routing");
            Assert(DandanApi.ResolveUseOfficialProxyCors(explicitOfficial) &&
                   !DandanApi.ResolveUseOfficialProxyCors(explicitCustom),
                "explicit official CORS choices must take precedence over the custom-prefix value");

            explicitCustom.ProxyCorsUrl = string.Empty;
            Assert(!DandanApi.ResolveUseOfficialProxyCors(explicitCustom),
                "an explicit false choice must not reset when the custom prefix is empty");
            explicitOfficial.ProxyCorsUrl = "https://worker.example/cors/";
            Assert(DandanApi.ResolveUseOfficialProxyCors(explicitOfficial),
                "an explicit true choice must remain selected when a custom prefix is retained");

            string serialized;
            using (var writer = new StringWriter())
            {
                serializer.Serialize(writer, explicitOfficial);
                serialized = writer.ToString();
            }
            Assert(serialized.Contains("UseOfficialProxyCors") &&
                   !serialized.Contains("workers.dev", StringComparison.OrdinalIgnoreCase),
                "serializing the official CORS selection must persist only the boolean choice");
        }

        private static void NormalizesAndValidatesDandanProxyPrefixes()
        {
            Assert(
                DandanApi.NormalizeProxyCorsUrl("  https://worker.example/cors  ") ==
                "https://worker.example/cors/",
                "proxy CORS prefixes should be trimmed and receive one trailing slash");
            Assert(
                DandanApi.NormalizeProxyCorsUrl("https://worker.example/cors////") ==
                "https://worker.example/cors/",
                "repeated trailing slashes should normalize to exactly one slash");

            var invalidPrefixes = new[]
            {
                string.Empty,
                "relative/cors/",
                "ftp://worker.example/cors/",
                "https://worker.example/cors/?token=LEAK_QUERY",
                "https://worker.example/cors/#LEAK_FRAGMENT"
            };
            foreach (var invalidPrefix in invalidPrefixes)
            {
                var message = CaptureProxyPrefixError(invalidPrefix);
                Assert(message.Contains("missing or invalid"),
                    "invalid proxy prefixes should produce a deterministic configuration error");
                Assert((invalidPrefix.Length == 0 || !message.Contains(invalidPrefix)) &&
                       !message.Contains("LEAK_QUERY") &&
                       !message.Contains("LEAK_FRAGMENT"),
                    "proxy configuration errors must not echo the configured value");
            }
        }

        private static string CaptureProxyPrefixError(string proxyCorsUrl)
        {
            try
            {
                DandanApi.NormalizeProxyCorsUrl(proxyCorsUrl);
                throw new InvalidOperationException("expected proxy prefix validation to fail");
            }
            catch (InvalidOperationException ex)
            {
                return ex.Message;
            }
        }

        private static void RoutesExistingDandanEndpointsWithoutLocalProxyAuthentication()
        {
            const string proxyPrefix = "https://worker.example/cors/";
            var officialUrls = new[]
            {
                "https://api.dandanplay.net/api/v2/search/anime?keyword=Frieren%20S2",
                "https://api.dandanplay.net/api/v2/bangumi/12345",
                "https://api.dandanplay.net/api/v2/comment/67890?withRelated=true&chConvert=2"
            };

            foreach (var officialUrl in officialUrls)
            {
                Assert(DandanApi.RouteOfficialUrl(officialUrl, false, false, string.Empty) == officialUrl,
                    "custom API mode should preserve the exact official URL");
                Assert(DandanApi.RouteOfficialUrl(officialUrl, true, false, proxyPrefix) ==
                       proxyPrefix + officialUrl,
                    "custom proxy mode should preserve the complete endpoint and query string");
            }

            var officialRoutes = officialUrls
                .Select(url => DandanApi.RouteOfficialUrl(url, true, true, string.Empty))
                .ToList();
            var officialPrefixLength = officialRoutes[0].Length - officialUrls[0].Length;
            var officialPrefix = officialRoutes[0].Substring(0, officialPrefixLength);
            Assert(!string.IsNullOrWhiteSpace(officialPrefix) && officialRoutes.Select((route, index) =>
                       route == officialPrefix + officialUrls[index]).All(value => value),
                "official CORS mode should route every endpoint through one exact backend prefix");

            Assert(DandanApi.ShouldAddLocalAuthentication(false),
                "custom API mode should retain local Dandanplay signing");
            Assert(!DandanApi.ShouldAddLocalAuthentication(true),
                "proxy API mode should not add local Dandanplay authentication");
            Assert(DandanApi.RouteOfficialUrl(officialUrls[0], true, false, proxyPrefix).Contains("search/anime"),
                "proxy routing should succeed independently of any local credential resolver");
            Assert(!DandanApi.ResolveUseOfficialProxyCors(new DandanOption
            {
                UseOfficialProxyCors = false,
                ProxyCorsUrl = proxyPrefix,
            }), "custom CORS mode must not fall back to official routing");
        }

        private static void PreservesDandanTitleBasedMatchingEndpoints()
        {
            var sourcePath = Path.GetFullPath(Path.Combine(
                AppContext.BaseDirectory, "..", "..", "..", "..", "Scraper", "Dandan", "DandanApi.cs"));
            var source = File.ReadAllText(sourcePath);

            Assert(source.Contains("search/anime") && source.Contains("bangumi/") && source.Contains("comment/"),
                "Dandan should retain its search, bangumi, and comment endpoint pipeline");
            Assert(source.IndexOf("/match", StringComparison.OrdinalIgnoreCase) < 0 &&
                   source.IndexOf("fileHash", StringComparison.OrdinalIgnoreCase) < 0,
                "Dandan must not introduce dd-danmaku hash matching");
            Assert(!Regex.IsMatch(source,
                    "(?:_logger|logger)\\.[A-Za-z]+\\([^;]*(?:ApiId|ApiSecret|X-Signature|signature)",
                    RegexOptions.IgnoreCase),
                "Dandan request logging must not include credential, signature, or authentication-header values");
        }

        private static void EmbedsDandanCredentialSettings()
        {
            var assembly = typeof(DandanCredentialResolver).Assembly;
            var names = assembly.GetManifestResourceNames();
            var html = ReadResource(assembly, names.Single(x => x.EndsWith("configPage.html", StringComparison.OrdinalIgnoreCase)));
            var script = ReadResource(assembly, names.Single(x => x.EndsWith("config.js", StringComparison.OrdinalIgnoreCase)));

            Assert(html.Contains("id=\"DandanApiId\""), "settings page should contain the Dandan API ID input");
            Assert(html.Contains("id=\"DandanApiSecret\"") && html.Contains("type=\"password\""),
                "settings page should mask the Dandan API Secret");
            Assert(html.Contains("id=\"UseProxyApi\"") && html.Contains("id=\"UseCustomApi\"") &&
                   CountOccurrences(html, "name=\"DandanApiMode\"") == 2,
                "settings page should contain two mutually exclusive Dandan API mode radios");
            Assert(html.Contains("id=\"ProxyCorsUrl\"") && html.Contains("id=\"DandanProxyApiSettings\"") &&
                   html.Contains("id=\"DandanCustomApiSettings\""),
                "settings page should contain the proxy CORS input and both conditional sections");
            Assert(html.Contains("id=\"UseOfficialProxyCors\"") &&
                   !html.Contains("workers.dev", StringComparison.OrdinalIgnoreCase),
                "settings page should expose only the official-CORS choice, never its backend address");
            Assert(!html.Contains("id=\"ProxyCorsUrl\" value="),
                "settings page must not prefill or embed a proxy CORS URL");
            Assert(script.Contains("config.Dandan.ApiId") && script.Contains("config.Dandan.ApiSecret"),
                "settings script should load both Dandan credential values");
            Assert(script.Contains("config.Dandan.UseProxyApi === true") &&
                   script.Contains("config.Dandan.ProxyCorsUrl || ''"),
                "settings script should load the API mode and proxy CORS prefix with legacy-safe defaults");
            Assert(script.Contains("dandan.ApiId") && script.Contains("dandan.ApiSecret") &&
                   script.Contains("dandan.WithRelatedDanmu") && script.Contains("dandan.ChConvert"),
                "settings script should save credentials without dropping existing Dandan options");
            Assert(script.Contains("dandan.UseProxyApi") && script.Contains("dandan.ProxyCorsUrl"),
                "settings script should save the selected API mode and proxy CORS prefix");
            Assert(script.Contains("resolveUseOfficialProxyCors") && script.Contains("dandan.UseOfficialProxyCors") &&
                   script.Contains("ProxyCorsUrl').disabled = !useProxyApi || useOfficialProxyCors"),
                "settings script should migrate legacy choices, persist an explicit boolean, and disable only the active official route input");
            Assert(script.Contains("classList.toggle('hide', !useProxyApi)") &&
                   script.Contains("classList.toggle('hide', useProxyApi)"),
                "settings script should switch proxy and custom field visibility");
            Assert(!script.Contains("DandanApiId').value = ''") &&
                   !script.Contains("DandanApiSecret').value = ''") &&
                   !script.Contains("ProxyCorsUrl').value = ''"),
                "switching API modes must not clear inactive values");
        }

        private static void VerifiesVersionedConfigurationPageResources()
        {
            var assembly = typeof(DandanCredentialResolver).Assembly;
            var generatedType = assembly.GetType("Emby.Plugin.Danmu.Configuration.GeneratedConfigurationPageResources");
            Assert(generatedType != null, "the build should compile generated configuration-page resource names");
            var token = (string)generatedType.GetField("CacheToken", BindingFlags.Static | BindingFlags.NonPublic)
                .GetRawConstantValue();
            var pageName = (string)generatedType.GetField("PageName", BindingFlags.Static | BindingFlags.NonPublic)
                .GetRawConstantValue();
            var controllerName = (string)generatedType.GetField("ControllerName", BindingFlags.Static | BindingFlags.NonPublic)
                .GetRawConstantValue();
            var informationalVersion = assembly.GetCustomAttribute<AssemblyInformationalVersionAttribute>()?.InformationalVersion;

            Assert(token == NormalizeCacheToken(informationalVersion) &&
                   Regex.IsMatch(token, "^[A-Za-z0-9_-]+$"),
                "the generated cache token should normalize informational-version metadata to a URL-safe identifier");
            Assert(pageName == "danmu-" + token && controllerName == "danmuJs-" + token,
                "configuration page and controller identifiers must share the generated token");
            Assert(NormalizeCacheToken("2.0.1+r5") == "2-0-1-r5",
                "cache-token normalization should replace unsafe build-metadata punctuation");

            var names = assembly.GetManifestResourceNames();
            var html = ReadResource(assembly, names.Single(x => x.EndsWith("configPage.html", StringComparison.OrdinalIgnoreCase)));
            Assert(html.Contains("data-controller=\"__plugin/" + controllerName + "\"") &&
                   !html.Contains("__DANMU_CONFIG_CACHE_TOKEN__", StringComparison.Ordinal),
                "the embedded configuration page should contain the matching generated controller without a placeholder");

            var pluginSource = File.ReadAllText(Path.GetFullPath(Path.Combine(
                AppContext.BaseDirectory, "..", "..", "..", "..", "Plugin.cs")));
            Assert(pluginSource.Contains("GeneratedConfigurationPageResources.PageName") &&
                   pluginSource.Contains("GeneratedConfigurationPageResources.ControllerName"),
                "PluginPageInfo registration should use generated matched identifiers");
        }

        private static string NormalizeCacheToken(string informationalVersion)
        {
            var token = Regex.Replace(informationalVersion ?? string.Empty, "[^A-Za-z0-9_-]+", "-");
            token = Regex.Replace(token, "(^-+|-+$)", string.Empty);
            return string.IsNullOrEmpty(token) ? "build" : token;
        }

        private static void VerifiesSingleTargetSmartMatchReliabilityContracts()
        {
            var controllerSource = File.ReadAllText(Path.GetFullPath(Path.Combine(
                AppContext.BaseDirectory, "..", "..", "..", "..", "Core", "Controllers", "DanmuController.cs")));
            Assert(controllerSource.Contains("task.MatchOrigin, \"provider-id\"") &&
                   controllerSource.Contains("ResolveDirectEpisodeMediaAsync("),
                "direct Episode ProviderId retries must stay on GetMediaEpisode instead of treating the id as a Season id");

            Assert(DanmuEpisodeMatchHelper.SuggestSourceEpisodeNumber(null, 12) == null &&
                   DanmuEpisodeMatchHelper.SuggestSourceEpisodeNumber(1, 0) == null &&
                   !DanmuEpisodeMatchHelper.IsValidSourceEpisodeNumber(-1, 12),
                "Episode suggestions should reject missing, special, and unavailable source numbers without affecting siblings");

            var lateProvider = new TaskCompletionSource<DanmuEpisodeDownloadOutcome>(
                TaskCreationOptions.RunContinuationsAsynchronously);
            var timedOut = false;
            var timeoutOutcome = SingleTargetDownloadArbiter.AwaitAsync(
                    lateProvider.Task,
                    TimeSpan.FromMilliseconds(20),
                    CancellationToken.None,
                    onTimeout: () => timedOut = true)
                .GetAwaiter().GetResult();
            Assert(timeoutOutcome.Status == "skipped" && timedOut,
                "a single-target provider that exceeds its deadline should become skipped");
            Assert(timeoutOutcome.Message.Contains("20") && !timeoutOutcome.Message.Contains("180"),
                "timeout diagnostics should describe the configured deadline instead of a hard-coded 180 seconds");
            lateProvider.SetResult(new DanmuEpisodeDownloadOutcome { Status = "success", Message = "late" });
            Assert(timeoutOutcome.Status == "skipped",
                "a late provider completion must not overwrite the already selected timeout result");

            var providerSkipped = false;
            var duplicateSkipOutcome = SingleTargetDownloadArbiter.AwaitAsync(
                    Task.FromResult(new DanmuEpisodeDownloadOutcome { Status = "skipped", Message = "duplicate" }),
                    TimeSpan.FromSeconds(1),
                    CancellationToken.None,
                    onTimeout: () => providerSkipped = true)
                .GetAwaiter().GetResult();
            Assert(duplicateSkipOutcome.Status == "skipped" && !providerSkipped,
                "a provider-reported duplicate skip must not be reported as a timeout");

            using (var cancellation = new CancellationTokenSource())
            {
                cancellation.Cancel();
                var cancelledProvider = new TaskCompletionSource<DanmuEpisodeDownloadOutcome>(
                    TaskCreationOptions.RunContinuationsAsynchronously);
                var cancelled = false;
                try
                {
                    SingleTargetDownloadArbiter.AwaitAsync(
                            cancelledProvider.Task,
                            TimeSpan.FromSeconds(1),
                            cancellation.Token)
                        .GetAwaiter().GetResult();
                }
                catch (OperationCanceledException)
                {
                    cancelled = true;
                }
                Assert(cancelled,
                    "a cancelled single-target task must complete as cancelled without waiting for its provider");
            }

            using (var simultaneousCancellation = new CancellationTokenSource())
            {
                simultaneousCancellation.Cancel();
                var cancelled = false;
                try
                {
                    SingleTargetDownloadArbiter.AwaitAsync(
                            Task.FromResult(new DanmuEpisodeDownloadOutcome
                            {
                                Status = "success",
                                Message = "provider completed",
                            }),
                            TimeSpan.FromSeconds(1),
                            simultaneousCancellation.Token)
                        .GetAwaiter().GetResult();
                }
                catch (OperationCanceledException)
                {
                    cancelled = true;
                }

                Assert(cancelled,
                    "cancellation must win when the cancellation signal and provider result are both already complete");
            }
        }

        private static int CountOccurrences(string text, string value)
        {
            var count = 0;
            var index = 0;
            while ((index = text.IndexOf(value, index, StringComparison.Ordinal)) >= 0)
            {
                count++;
                index += value.Length;
            }

            return count;
        }

        private static void PreservesValidUnicodeWhileRemovingInvalidXmlScalars()
        {
            var source = "中文\t换行\n回车\remoji😀尾部" + '\u0001' + '\uFFFE' + '\uFFFF' +
                         "\uD800孤立高代理\uDC00孤立低代理";
            var sanitized = Xml10Sanitizer.SanitizeText(source);

            Assert(sanitized.Contains("中文\t换行\n回车\remoji😀尾部"),
                "valid Chinese, whitespace, and supplementary Unicode should be preserved");
            Assert(!sanitized.Contains('\u0001') && !sanitized.Contains('\uFFFE') &&
                   !sanitized.Contains('\uFFFF') && !sanitized.Contains("\uD800") &&
                   !sanitized.Contains("\uDC00"),
                "invalid XML scalars and isolated surrogates should be removed");
        }

        private static void RemovesInvalidXmlCharacterReferences()
        {
            const string source = "<root>保留&#10;&#x1F600;移除&#0;&#xB;&#65535;&#x110000;</root>";
            var sanitized = Xml10Sanitizer.SanitizeDocument(source);
            var document = new XmlDocument();
            document.LoadXml(sanitized);

            Assert(sanitized.Contains("&#10;") && sanitized.Contains("&#x1F600;"),
                "legal numeric XML character references should be preserved");
            Assert(!sanitized.Contains("&#0;") && !sanitized.Contains("&#xB;") &&
                   !sanitized.Contains("&#65535;") && !sanitized.Contains("&#x110000;"),
                "illegal numeric XML character references should be removed");
        }

        private static void PreservesCharacterReferenceTextInsideCdata()
        {
            const string source = "<root><![CDATA[字面文本 &#xFFFF; 和 &#0;]]><value>&#xFFFF;</value></root>";
            var sanitized = Xml10Sanitizer.SanitizeDocument(source);
            var document = new XmlDocument();
            document.LoadXml(sanitized);

            Assert(document.DocumentElement.FirstChild.Value == "字面文本 &#xFFFF; 和 &#0;",
                "numeric-reference-like text inside CDATA should remain literal and unchanged");
            Assert(document.DocumentElement.SelectSingleNode("value").InnerText == string.Empty,
                "an illegal numeric character reference outside CDATA should still be removed");
        }

        private static void RecoversIqiyiXmlContainingInvalidCharacters()
        {
            var xml = "<danmu><sum>1</sum><validSum>1</validSum><duration>1</duration>" +
                      "<data><entry><int>1</int><list><bulletInfo>" +
                      "<contentId>1</contentId><content>中文\n😀\uFFFF尾部&#0;</content>" +
                      "<font>1</font><color>FFFFFF</color><showTime>1</showTime>" +
                      "</bulletInfo></list></entry></data></danmu>";
            var cleaned = IqiyiApi.RemoveInvalidXmlChars(xml);
            var serializer = new XmlSerializer(typeof(IqiyiCommentDocument));
            IqiyiCommentDocument result;
            using (var reader = new StringReader(cleaned))
            {
                result = (IqiyiCommentDocument)serializer.Deserialize(reader);
            }

            Assert(result.Data[0].List[0].Content == "中文\n😀尾部",
                "Iqiyi fallback should remove invalid XML data without damaging valid comment text");
        }

        private static void RecoversBilibiliXmlContainingInvalidCharacters()
        {
            var xml = "<i><d p=\"1,1,25,16777215,0,0,user,1,1\">中文\n😀\uFFFF尾部&#0;</d></i>";
            var result = Emby.Plugin.Danmu.Scraper.Bilibili.Bilibili.ParseXml(xml);

            Assert(result.Items.Count == 1 && result.Items[0].Content == "中文\n😀尾部",
                "Bilibili XML fallback should recover a comment containing invalid XML data");
        }

        private static void SanitizesFinalXmlForEveryProviderAndAcceptsSmallValidOutput()
        {
            var providers = new[] { "BilibiliID", "IqiyiID", "TencentID", "YoukuID", "MgtvID", "DandanID" };
            foreach (var provider in providers)
            {
                var danmaku = new ScraperDanmaku
                {
                    ProviderId = provider,
                    Items = new List<ScraperDanmakuText>
                    {
                        new ScraperDanmakuText
                        {
                            Id = 1,
                            Progress = 1000,
                            MidHash = "用户\uFFFF😀",
                            Content = "中文\n😀\u0001\uFFFE\uFFFF尾部"
                        }
                    }
                };

                Assert(DanmuDownloadContent.HasUsableItems(danmaku),
                    "a single valid comment should be usable regardless of provider");
                var bytes = DanmuDownloadContent.Serialize(danmaku);
                Assert(bytes.Length < 1024,
                    "the regression fixture should remain below the removed one-kilobyte threshold");

                var document = new XmlDocument();
                document.LoadXml(Encoding.UTF8.GetString(bytes));
                var finalContent = document.DocumentElement.SelectSingleNode("d").InnerText;
                Assert(finalContent.Replace("\r\n", "\n") == "中文\n😀尾部",
                    "final XML should preserve valid text and remove invalid characters for " + provider +
                    "; actual=" + finalContent);
            }

            Assert(!DanmuDownloadContent.HasUsableItems(new ScraperDanmaku()),
                "an empty danmu result should not be treated as usable");
        }

        private static string ReadResource(System.Reflection.Assembly assembly, string name)
        {
            using (var stream = assembly.GetManifestResourceStream(name))
            using (var reader = new StreamReader(stream))
            {
                return reader.ReadToEnd();
            }
        }

        private static DanmuMatchCandidate Candidate(string id, string site, int sourceOrder, double score)
        {
            return new DanmuMatchCandidate
            {
                Id = id,
                Name = id,
                Site = site,
                SiteName = site,
                SourceOrder = sourceOrder,
                Score = score
            };
        }

        private static void ParsesIqiyiQipsMovieTvId()
        {
            var method = typeof(IqiyiApi).GetMethod(
                "ExtractTvId",
                System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Static);
            var parsed = (long)method.Invoke(null, new object[]
            {
                "qips://tvid=243967400;vid=eb299ecdb0803913ed5139ee05062de9;"
            });
            Assert(parsed == 243967400, "iQIYI qips movie URLs should expose their TvId");
        }

        private sealed class FakeScraper : AbstractScraper
        {
            private readonly string _providerId;
            private readonly List<ScraperSearchInfo> _results;
            private readonly bool _throws;
            private readonly Dictionary<string, ScraperMedia> _mediaById;
            private readonly Dictionary<string, ScraperEpisode> _episodesById;
            private readonly Dictionary<string, List<ScraperSearchInfo>> _apiResultsByKeyword;
            private readonly Dictionary<string, List<ScraperSearchInfo>> _movieResultsByKeyword;
            public int MediaCalls { get; private set; }
            public int MediaEpisodeCalls { get; private set; }
            public int SearchCalls { get; private set; }
            public List<string> ApiKeywords { get; } = new List<string>();
            public List<string> SearchNames { get; } = new List<string>();

            public FakeScraper(
                string providerId,
                List<ScraperSearchInfo> results,
                bool throws = false,
                Dictionary<string, ScraperMedia> mediaById = null,
                Dictionary<string, ScraperEpisode> episodesById = null,
                Dictionary<string, List<ScraperSearchInfo>> apiResultsByKeyword = null,
                Dictionary<string, List<ScraperSearchInfo>> movieResultsByKeyword = null)
                : base(null)
            {
                _providerId = providerId;
                _results = results;
                _throws = throws;
                _mediaById = mediaById ?? new Dictionary<string, ScraperMedia>(StringComparer.OrdinalIgnoreCase);
                _episodesById = episodesById ?? new Dictionary<string, ScraperEpisode>(StringComparer.OrdinalIgnoreCase);
                _apiResultsByKeyword = apiResultsByKeyword ??
                    new Dictionary<string, List<ScraperSearchInfo>>(StringComparer.OrdinalIgnoreCase);
                _movieResultsByKeyword = movieResultsByKeyword;
            }

            public override string Name => _providerId;
            public override string ProviderName => _providerId;
            public override string ProviderId => _providerId;

            public override Task<List<ScraperSearchInfo>> Search(BaseItem item)
            {
                SearchCalls++;
                SearchNames.Add(item?.Name ?? string.Empty);
                if (_throws) throw new InvalidOperationException("provider failed");
                if (_movieResultsByKeyword != null)
                {
                    _movieResultsByKeyword.TryGetValue(item?.Name ?? string.Empty, out var keywordResults);
                    return Task.FromResult(keywordResults ?? new List<ScraperSearchInfo>());
                }
                return Task.FromResult(_results ?? new List<ScraperSearchInfo>());
            }

            public override Task<string> SearchMediaId(BaseItem item) => Task.FromResult(string.Empty);
            public override Task<List<ScraperSearchInfo>> SearchForApi(string keyword)
            {
                ApiKeywords.Add(keyword);
                if (_throws) throw new InvalidOperationException("provider failed");
                _apiResultsByKeyword.TryGetValue(keyword ?? string.Empty, out var results);
                return Task.FromResult(results ?? new List<ScraperSearchInfo>());
            }
            public override Task<ScraperMedia> GetMedia(BaseItem item, string id)
            {
                MediaCalls++;
                _mediaById.TryGetValue(id ?? string.Empty, out var media);
                return Task.FromResult(media);
            }
            public override Task<ScraperEpisode> GetMediaEpisode(BaseItem item, string id)
            {
                MediaEpisodeCalls++;
                _episodesById.TryGetValue(id ?? string.Empty, out var episode);
                return Task.FromResult(episode);
            }
            public override Task<ScraperDanmaku> GetDanmuContent(BaseItem item, string commentId) => Task.FromResult<ScraperDanmaku>(null);
        }

        private static void Assert(bool condition, string message)
        {
            if (!condition)
            {
                throw new InvalidOperationException(message);
            }
        }
    }
}
