# Verification Record

## Deterministic checks

- `dotnet restore Emby.Plugin.Danmu.sln`: passed.
- `dotnet build Emby.Plugin.Danmu.sln -c Release --no-restore`: passed with 0 errors.
- `dotnet run --project RegressionTests/Emby.Plugin.Danmu.RegressionTests.csproj -c Release --no-restore`: passed.
- `node Frontend/DanmuSmartMatch.RegressionTests.js`: passed.
- `node --check Configuration/config.js`: passed.
- `openspec validate add-dandan-api-proxy-mode --strict`: passed.

The routing regressions cover legacy defaults, proxy-prefix normalization and
sanitized rejection, exact search/bangumi/comment URLs and queries, direct-mode
authentication eligibility, proxy credential independence, configuration page
round-tripping, and provider failure isolation. The existing regression suite
also covers manual bindings, STRM episode handling, retry/partial XML behavior,
and deterministic descending-score selection.

## Live proxy and Emby checks

- Worker prefix: `https://ddplay-api.7o7o.cc/cors/`.
- A read-only proxied `/api/v2/search/anime` request for `葬送的芙莉莲`
  returned HTTP 200 and Dandanplay anime ID `17617`.
- Emby 4.9.3.0 loaded the legacy configuration as custom mode, then persisted
  proxy mode and the normalized Worker prefix across a restart.
- Series, season, and episode previews for `葬送的芙莉莲` returned Dandanplay
  candidates. Both automatic and manual episode matching resolved episode 1.
- A forced manual download for episode 1 using `DandanID=17617` completed with
  1 success and 0 failures. The Emby item subsequently contained a `DandanID`
  provider value.
- Other enabled providers continued returning candidates. The latest Emby log
  contained no Dandanplay error lines and no `X-AppId`, `X-Signature`,
  `ApiSecret`, or `API Secret` text.

The Emby media path is a library mapping that is not resolvable from the
Synology SSH namespace, so the generated XML could not be independently opened
through SSH. The completed download result and persisted provider ID were
verified through Emby's plugin and item APIs.

## Direct-mode limitation

The deployed legacy configuration contains no Dandanplay API ID/secret pair.
Custom mode migration and deterministic signing behavior are verified, but a
live signed Dandanplay search cannot be completed without a valid credential
pair. Proxy mode does not require those credentials.

## Deployment and rollback

- Installed DLL SHA-256:
  `880537df21380e641c8840e7ed7e5f3446235cf72acfa48f7d2880624ed8ce89`.
- Backup directory:
  `/volume2/@appdata/EmbyServer/plugins/backups/danmu-cfproxy-20260809-213233`.
- Previous DLL:
  `/volume2/@appdata/EmbyServer/plugins/backups/danmu-cfproxy-20260809-213233/Emby.Plugin.Danmu.dll.before`.
- Previous DLL SHA-256:
  `af577d53db934516a8787e0bb0ec9aaa5be6f1d41f172d584b4edde3be1db787`.
- Previous configuration:
  `/volume2/@appdata/EmbyServer/plugins/backups/danmu-cfproxy-20260809-213233/Emby.Plugin.Danmu.xml.before`.
- Previous configuration SHA-256:
  `6dea46df5bf6b05e345351bcc835ae1c86a99460de369ab97967661ffc76cd5d`.

Rollback: stop Emby, restore the two `.before` files to their original plugin
and configuration paths, set the DLL ownership to `emby:users` and mode to
`0644`, then start Emby. The backups and hashes were rechecked after deployment;
no rollback was needed.
